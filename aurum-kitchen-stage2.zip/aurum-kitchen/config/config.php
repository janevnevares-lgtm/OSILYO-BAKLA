<?php
/**
 * Global configuration.
 * Edit the values below to match your restaurant and server.
 */

// ---------- Brand ----------
define('APP_NAME',      'Aurum Kitchen');
define('APP_TAGLINE',   'Modern Filipino Fine Dining');
define('APP_EMAIL',     'hello@aurumkitchen.test');
define('APP_PHONE',     '+63 912 345 6789');
define('APP_ADDRESS',   '12 Heritage Avenue, Lopez, Quezon, Philippines');
define('CURRENCY',      '₱');

// ---------- Paths / URLs ----------
// Change BASE_URL if the site lives in a sub-folder, e.g. '/aurum-kitchen'
define('BASE_URL',  '/aurum-kitchen');
define('ROOT_PATH', dirname(__DIR__));
define('UPLOAD_DIR', ROOT_PATH . '/assets/images/uploads/');
define('UPLOAD_URL', BASE_URL . '/assets/images/uploads/');

// ---------- Database ----------
define('DB_HOST',    '127.0.0.1');
define('DB_NAME',    'aurum_kitchen');
define('DB_USER',    'root');
define('DB_PASS',    '');
define('DB_CHARSET', 'utf8mb4');

// ---------- Business rules ----------
define('TAX_RATE',          0.12);   // 12% VAT
define('DELIVERY_FEE',      80.00);
define('FREE_DELIVERY_MIN', 1500.00);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCK_MINUTES', 15);

// Reservation slots (24h format) and capacity per slot
define('RESERVATION_SLOTS', ['11:00','12:30','14:00','17:30','19:00','20:30']);
define('SLOT_CAPACITY', 40);          // total guests allowed per slot
define('MAX_PARTY_SIZE', 12);

// Set to false in production
define('APP_DEBUG', true);

date_default_timezone_set('Asia/Manila');

// ---------- Secure session ----------
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => !empty($_SERVER['HTTPS']),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_name('aurum_sid');
    session_start();
}

if (APP_DEBUG) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
}
