<?php
/**
 * POST /api/favorite.php  { "product_id": 5 }
 * Toggles a favourite for the signed-in user. Returns { favorited: bool }.
 */
require_once __DIR__ . '/../includes/auth.php';

if (!is_post()) {
    json_response(['error' => 'Method not allowed.'], 405);
}
if (!csrf_verify()) {
    json_response(['error' => 'Session expired. Please refresh the page.'], 419);
}
$user = current_user();
if (!$user) {
    json_response(['error' => 'Please sign in to save favorites.', 'login' => true], 401);
}

$body      = json_decode(file_get_contents('php://input'), true) ?: [];
$productId = (int) ($body['product_id'] ?? 0);

$check = db()->prepare('SELECT id FROM products WHERE id = ? AND is_available = 1');
$check->execute([$productId]);
if (!$check->fetch()) {
    json_response(['error' => 'Dish not found.'], 404);
}

$exists = db()->prepare('SELECT 1 FROM favorites WHERE user_id = ? AND product_id = ?');
$exists->execute([$user['id'], $productId]);

if ($exists->fetchColumn()) {
    db()->prepare('DELETE FROM favorites WHERE user_id = ? AND product_id = ?')->execute([$user['id'], $productId]);
    json_response(['favorited' => false]);
}
db()->prepare('INSERT INTO favorites (user_id, product_id) VALUES (?, ?)')->execute([$user['id'], $productId]);
json_response(['favorited' => true]);
