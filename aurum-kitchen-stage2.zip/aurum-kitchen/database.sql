-- ============================================================
-- Aurum Kitchen — database schema + seed data
-- Import with:  mysql -u root -p < database.sql
-- ============================================================
CREATE DATABASE IF NOT EXISTS aurum_kitchen
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE aurum_kitchen;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS login_attempts, order_status_history, promo_codes, favorites, reviews,
  reservations, order_items, orders, cart_items, product_options, products, categories,
  addresses, users;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------- users ----------
CREATE TABLE users (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(120) NOT NULL,
  email         VARCHAR(190) NOT NULL UNIQUE,
  phone         VARCHAR(30)  DEFAULT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('customer','admin') NOT NULL DEFAULT 'customer',
  is_active     TINYINT(1) NOT NULL DEFAULT 1,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_users_role (role)
) ENGINE=InnoDB;

-- ---------- login attempts (rate limiting) ----------
CREATE TABLE login_attempts (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  email        VARCHAR(190) NOT NULL,
  ip           VARCHAR(45)  NOT NULL,
  attempted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_attempts_email (email, attempted_at),
  INDEX idx_attempts_ip (ip, attempted_at)
) ENGINE=InnoDB;

-- ---------- addresses ----------
CREATE TABLE addresses (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  label       VARCHAR(50)  NOT NULL DEFAULT 'Home',
  line1       VARCHAR(190) NOT NULL,
  barangay    VARCHAR(120) DEFAULT NULL,
  city        VARCHAR(120) NOT NULL,
  province    VARCHAR(120) DEFAULT NULL,
  postal_code VARCHAR(12)  DEFAULT NULL,
  notes       VARCHAR(255) DEFAULT NULL,
  is_default  TINYINT(1) NOT NULL DEFAULT 0,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_addresses_user (user_id)
) ENGINE=InnoDB;

-- ---------- categories ----------
CREATE TABLE categories (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(80) NOT NULL,
  slug       VARCHAR(80) NOT NULL UNIQUE,
  sort_order INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

-- ---------- products ----------
CREATE TABLE products (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id  INT UNSIGNED NOT NULL,
  name         VARCHAR(140) NOT NULL,
  slug         VARCHAR(160) NOT NULL UNIQUE,
  short_desc   VARCHAR(255) NOT NULL,
  description  TEXT,
  ingredients  VARCHAR(500) DEFAULT NULL,
  allergens    VARCHAR(255) DEFAULT NULL,
  dietary_tags VARCHAR(120) DEFAULT NULL,       -- comma list: vegan,vegetarian,gluten-free,spicy
  price        DECIMAL(10,2) NOT NULL,
  image        VARCHAR(255) DEFAULT NULL,       -- URL or uploaded file name
  gallery      TEXT DEFAULT NULL,               -- pipe-separated extra image URLs
  rating       DECIMAL(2,1) NOT NULL DEFAULT 4.5,
  is_featured  TINYINT(1) NOT NULL DEFAULT 0,
  is_available TINYINT(1) NOT NULL DEFAULT 1,
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id),
  INDEX idx_products_category (category_id),
  INDEX idx_products_featured (is_featured, is_available),
  FULLTEXT INDEX ft_products_search (name, short_desc)
) ENGINE=InnoDB;

-- ---------- product options (sizes / add-ons) ----------
CREATE TABLE product_options (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  product_id  INT UNSIGNED NOT NULL,
  type        ENUM('size','addon') NOT NULL,
  name        VARCHAR(80) NOT NULL,
  price_delta DECIMAL(10,2) NOT NULL DEFAULT 0,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  INDEX idx_options_product (product_id)
) ENGINE=InnoDB;

-- ---------- promo codes ----------
CREATE TABLE promo_codes (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code           VARCHAR(40) NOT NULL UNIQUE,
  discount_type  ENUM('percent','fixed') NOT NULL,
  discount_value DECIMAL(10,2) NOT NULL,
  min_subtotal   DECIMAL(10,2) NOT NULL DEFAULT 0,
  expires_at     DATE DEFAULT NULL,
  usage_limit    INT UNSIGNED DEFAULT NULL,
  times_used     INT UNSIGNED NOT NULL DEFAULT 0,
  is_active      TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

-- ---------- cart (logged-in users) ----------
CREATE TABLE cart_items (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  product_id  INT UNSIGNED NOT NULL,
  quantity    SMALLINT UNSIGNED NOT NULL DEFAULT 1,
  options     VARCHAR(255) DEFAULT NULL,        -- comma list of product_options ids
  notes       VARCHAR(255) DEFAULT NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  INDEX idx_cart_user (user_id)
) ENGINE=InnoDB;

-- ---------- orders ----------
CREATE TABLE orders (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_number     VARCHAR(24) NOT NULL UNIQUE,
  user_id          INT UNSIGNED DEFAULT NULL,
  customer_name    VARCHAR(120) NOT NULL,
  customer_email   VARCHAR(190) DEFAULT NULL,
  customer_phone   VARCHAR(30)  NOT NULL,
  order_type       ENUM('delivery','pickup','dine_in') NOT NULL,
  delivery_address VARCHAR(400) DEFAULT NULL,
  scheduled_for    DATETIME DEFAULT NULL,
  payment_method   ENUM('cod','gcash','card') NOT NULL DEFAULT 'cod',
  payment_status   ENUM('pending','paid','failed') NOT NULL DEFAULT 'pending',
  status           ENUM('placed','confirmed','preparing','ready','completed','cancelled') NOT NULL DEFAULT 'placed',
  subtotal         DECIMAL(10,2) NOT NULL,
  discount         DECIMAL(10,2) NOT NULL DEFAULT 0,
  tax              DECIMAL(10,2) NOT NULL DEFAULT 0,
  delivery_fee     DECIMAL(10,2) NOT NULL DEFAULT 0,
  total            DECIMAL(10,2) NOT NULL,
  promo_code       VARCHAR(40) DEFAULT NULL,
  notes            VARCHAR(400) DEFAULT NULL,
  eta_minutes      SMALLINT UNSIGNED DEFAULT 45,
  created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_orders_user (user_id),
  INDEX idx_orders_status (status),
  INDEX idx_orders_created (created_at)
) ENGINE=InnoDB;

-- ---------- order items (snapshot of name/price at purchase time) ----------
CREATE TABLE order_items (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id     INT UNSIGNED NOT NULL,
  product_id   INT UNSIGNED DEFAULT NULL,
  product_name VARCHAR(140) NOT NULL,
  options_text VARCHAR(255) DEFAULT NULL,
  unit_price   DECIMAL(10,2) NOT NULL,
  quantity     SMALLINT UNSIGNED NOT NULL,
  line_total   DECIMAL(10,2) NOT NULL,
  notes        VARCHAR(255) DEFAULT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL,
  INDEX idx_items_order (order_id)
) ENGINE=InnoDB;

-- ---------- order status history (powers the tracking timeline) ----------
CREATE TABLE order_status_history (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id   INT UNSIGNED NOT NULL,
  status     VARCHAR(20) NOT NULL,
  note       VARCHAR(255) DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  INDEX idx_history_order (order_id)
) ENGINE=InnoDB;

-- ---------- reservations ----------
CREATE TABLE reservations (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reference        VARCHAR(20) NOT NULL UNIQUE,
  user_id          INT UNSIGNED DEFAULT NULL,
  name             VARCHAR(120) NOT NULL,
  email            VARCHAR(190) DEFAULT NULL,
  phone            VARCHAR(30)  NOT NULL,
  reservation_date DATE NOT NULL,
  reservation_time TIME NOT NULL,
  party_size       TINYINT UNSIGNED NOT NULL,
  special_requests VARCHAR(400) DEFAULT NULL,
  status           ENUM('pending','confirmed','cancelled','completed') NOT NULL DEFAULT 'pending',
  created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_res_slot (reservation_date, reservation_time),
  INDEX idx_res_user (user_id)
) ENGINE=InnoDB;

-- ---------- reviews ----------
CREATE TABLE reviews (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  product_id INT UNSIGNED NOT NULL,
  user_id    INT UNSIGNED NOT NULL,
  rating     TINYINT UNSIGNED NOT NULL,
  comment    VARCHAR(600) DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_review (product_id, user_id),
  CHECK (rating BETWEEN 1 AND 5)
) ENGINE=InnoDB;

-- ---------- favorites ----------
CREATE TABLE favorites (
  user_id    INT UNSIGNED NOT NULL,
  product_id INT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, product_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- SEED DATA
-- ============================================================

-- Demo accounts:  admin@aurumkitchen.test / Admin@123
--                 customer@aurumkitchen.test / Customer@123
INSERT INTO users (name, email, phone, password_hash, role) VALUES
('Aurum Admin',  'admin@aurumkitchen.test',    '+63 900 000 0001', '$2y$10$p9rdR53/4Wvb.oVGDcKHtuWYAI6C.h/QE.TYlLKcAwVkKODkIZVTu', 'admin'),
('Maria Santos', 'customer@aurumkitchen.test', '+63 900 000 0002', '$2y$10$mHJASgDmpHBJ9SmB3cg9KuyHpNUIkjl/Hz6SpWPA67v68i86K31h6', 'customer');

INSERT INTO addresses (user_id, label, line1, barangay, city, province, postal_code, is_default) VALUES
(2, 'Home', '45 Mabini Street', 'Brgy. Poblacion', 'Lopez', 'Quezon', '4316', 1);

INSERT INTO categories (name, slug, sort_order) VALUES
('Starters', 'starters', 1),
('Mains',    'mains',    2),
('Desserts', 'desserts', 3),
('Drinks',   'drinks',   4);

INSERT INTO products
(category_id, name, slug, short_desc, description, ingredients, allergens, dietary_tags, price, image, gallery, rating, is_featured) VALUES
(1,'Kinilaw na Tanigue','kinilaw-na-tanigue','Cured Spanish mackerel, coconut vinegar, calamansi, finger chili.',
 'Line-caught tanigue gently cured in cane vinegar and fresh calamansi, finished with coconut cream foam and pickled ginger.',
 'Tanigue, coconut vinegar, calamansi, ginger, red onion, finger chili, coconut cream','Fish','gluten-free,spicy',420.00,
 'https://images.unsplash.com/photo-1535399831218-d5bd36d1a6b3?auto=format&fit=crop&w=1000&q=70',
 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&w=1000&q=70|https://images.unsplash.com/photo-1467003909585-2f8a72700288?auto=format&fit=crop&w=1000&q=70',4.8,1),
(1,'Lumpiang Ubod','lumpiang-ubod','Heart-of-palm spring rolls with garlic-peanut glaze.',
 'Fresh ubod rolled in a hand-made crepe, drizzled with a slow-cooked garlic and peanut sauce.',
 'Heart of palm, shrimp, jicama, carrot, crepe wrapper, peanuts, garlic','Shellfish, Peanuts, Gluten','',360.00,
 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1000&q=70',NULL,4.6,0),
(1,'Crispy Sisig Tacos','crispy-sisig-tacos','Pork cheek sisig, calamansi aioli, pickled red onion.',
 'Three handmade corn tortillas filled with charred pork cheek sisig, finished with a soft egg yolk jam.',
 'Pork cheek, corn tortilla, calamansi, onion, chili, egg yolk','Egg, Gluten','spicy',390.00,
 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?auto=format&fit=crop&w=1000&q=70',NULL,4.7,1),
(1,'Roasted Pumpkin Soup','roasted-pumpkin-soup','Kalabasa velouté, toasted pili nuts, coconut oil.',
 'Silky roasted squash soup with a hint of ginger and crisp toasted pili.',
 'Kalabasa, coconut milk, ginger, pili nuts, garlic','Tree nuts','vegan,vegetarian,gluten-free',310.00,
 'https://images.unsplash.com/photo-1476718406336-bb5a9690ee2a?auto=format&fit=crop&w=1000&q=70',NULL,4.4,0),

(2,'Wagyu Beef Kare-Kare','wagyu-beef-kare-kare','Slow-braised wagyu cheek, peanut sauce, bagoong, grilled vegetables.',
 'Eight-hour braised wagyu cheek in a silky annatto and peanut sauce, served with burnt-butter vegetables and house bagoong.',
 'Wagyu beef cheek, peanuts, annatto, eggplant, sitaw, bok choy, shrimp paste','Peanuts, Shellfish','',1280.00,
 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1000&q=70',
 'https://images.unsplash.com/photo-1558030006-450675393462?auto=format&fit=crop&w=1000&q=70',4.9,1),
(2,'Adobo-Glazed Duck Breast','adobo-glazed-duck-breast','Pan-seared duck, soy-cane vinegar glaze, garlic rice crisp.',
 'Dry-aged duck breast with a lacquered adobo glaze, served over garlic rice crisps with pickled mustard greens.',
 'Duck breast, soy, cane vinegar, garlic, bay leaf, peppercorn, rice','Soy, Gluten','',1050.00,
 'https://images.unsplash.com/photo-1544148103-0773bf10d330?auto=format&fit=crop&w=1000&q=70',NULL,4.8,1),
(2,'Lechon Kawali Royale','lechon-kawali-royale','Twice-cooked pork belly, liver sauce reduction, atchara.',
 'Crackling pork belly cooked sous-vide then deep-fried, with a refined liver sauce and house-pickled papaya.',
 'Pork belly, liver, vinegar, papaya, carrot, garlic','Gluten','',890.00,
 'https://images.unsplash.com/photo-1432139555190-58524dae6a55?auto=format&fit=crop&w=1000&q=70',NULL,4.7,0),
(2,'Seared Scallops in Bicol Express','seared-scallops-bicol-express','Hokkaido scallops, creamy coconut-chili sauce, crisp malunggay.',
 'Hokkaido scallops seared golden and set on a velvety Bicol Express sauce with fried moringa leaves.',
 'Scallops, coconut cream, siling labuyo, shrimp paste, malunggay','Shellfish','spicy,gluten-free',1120.00,
 'https://images.unsplash.com/photo-1599084993091-1cb5c0721cc6?auto=format&fit=crop&w=1000&q=70',NULL,4.8,1),
(2,'Mushroom Sinigang','mushroom-sinigang','Wild mushrooms in tamarind broth, kangkong, radish.',
 'A bright, soulful sinigang built on roasted tamarind with a medley of wild mushrooms.',
 'Mushrooms, tamarind, kangkong, radish, tomato, onion','','vegan,vegetarian,gluten-free',640.00,
 'https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=1000&q=70',NULL,4.5,0),

(3,'Ube Basque Cheesecake','ube-basque-cheesecake','Burnt ube cheesecake, coconut macapuno, salted caramel.',
 'Creamy, caramelised-top cheesecake made with Bukidnon ube, served with macapuno and salted caramel.',
 'Ube, cream cheese, eggs, cream, macapuno','Dairy, Egg, Gluten','vegetarian',380.00,
 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?auto=format&fit=crop&w=1000&q=70',NULL,4.9,1),
(3,'Halo-Halo Deconstructed','halo-halo-deconstructed','Shaved ice, leche flan, sweet beans, ube ice cream.',
 'Our fine-dining take on halo-halo: a tower of shaved ice, leche flan, saba, and house-churned ube ice cream.',
 'Shaved ice, evaporated milk, leche flan, saba, sweet beans, ube ice cream','Dairy, Egg','vegetarian',340.00,
 'https://images.unsplash.com/photo-1563805042-7684c019e1cb?auto=format&fit=crop&w=1000&q=70',NULL,4.6,0),
(3,'Dark Tablea Chocolate Torte','dark-tablea-chocolate-torte','Batangas tablea, sea salt, calamansi sorbet.',
 'Dense, flourless tablea torte finished with flaky sea salt and a sharp calamansi sorbet.',
 'Tablea chocolate, butter, eggs, sugar, calamansi','Dairy, Egg','vegetarian,gluten-free',360.00,
 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=1000&q=70',NULL,4.7,0),

(4,'Calamansi Mule','calamansi-mule','Calamansi, ginger beer, lemongrass, mint.',
 'A zero-proof refresher with fresh calamansi, spicy ginger beer and bruised lemongrass.',
 'Calamansi, ginger beer, lemongrass, mint, cane syrup','','vegan,vegetarian,gluten-free',220.00,
 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=1000&q=70',NULL,4.5,0),
(4,'Barako Cold Brew','barako-cold-brew','Batangas barako, muscovado, oat cream.',
 'Bold, chocolatey 18-hour cold brew from Batangas barako beans with muscovado syrup.',
 'Barako coffee, muscovado, oat milk','','vegan,vegetarian,gluten-free',240.00,
 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=1000&q=70',NULL,4.6,0),
(4,'Tsokolate Eh','tsokolate-eh','Thick hot tablea chocolate, whipped coconut cream.',
 'Traditional Filipino hot chocolate, whisked until velvety and topped with coconut cream.',
 'Tablea, milk, sugar, coconut cream','Dairy','vegetarian,gluten-free',260.00,
 'https://images.unsplash.com/photo-1542990253-0d0f5be5f0ed?auto=format&fit=crop&w=1000&q=70',NULL,4.7,0);

-- Options: sizes for mains / sharing portions, add-ons for several dishes
INSERT INTO product_options (product_id, type, name, price_delta) VALUES
(5,'size','Regular',0),(5,'size','Sharing (2 pax)',900),
(5,'addon','Extra garlic rice',90),(5,'addon','Side of bagoong',60),
(6,'size','Regular',0),(6,'size','Sharing (2 pax)',780),
(6,'addon','Extra garlic rice',90),
(7,'size','Regular',0),(7,'size','Sharing (2 pax)',650),
(7,'addon','Extra atchara',50),
(8,'addon','Extra garlic rice',90),
(1,'addon','Extra calamansi',20),(3,'addon','Extra egg yolk jam',40),
(10,'addon','Extra macapuno',60),(10,'addon','Scoop of ube ice cream',90),
(13,'size','Regular',0),(13,'size','Large',60),
(14,'size','Regular',0),(14,'size','Large',60);

INSERT INTO promo_codes (code, discount_type, discount_value, min_subtotal, expires_at, usage_limit) VALUES
('WELCOME10','percent',10,500,'2027-12-31',NULL),
('AURUM100','fixed',100,1000,'2027-12-31',500);

-- Sample completed order for the demo customer (so tracking & receipt work immediately)
-- subtotal 1660 -> VAT 12% = 199.20 -> delivery free (>= 1500) -> total 1859.20
INSERT INTO orders (order_number, user_id, customer_name, customer_email, customer_phone, order_type, delivery_address,
  payment_method, payment_status, status, subtotal, discount, tax, delivery_fee, total, eta_minutes)
VALUES ('AK-DEMO-0001', 2, 'Maria Santos', 'customer@aurumkitchen.test', '+63 900 000 0002', 'delivery',
  '45 Mabini Street, Brgy. Poblacion, Lopez, Quezon 4316', 'cod', 'paid', 'completed',
  1660.00, 0, 199.20, 0.00, 1859.20, 45);

INSERT INTO order_items (order_id, product_id, product_name, options_text, unit_price, quantity, line_total) VALUES
(1, 5, 'Wagyu Beef Kare-Kare', 'Regular', 1280.00, 1, 1280.00),
(1, 10, 'Ube Basque Cheesecake', NULL, 380.00, 1, 380.00);

INSERT INTO order_status_history (order_id, status, note) VALUES
(1,'placed','Order received'),(1,'confirmed','Confirmed by the kitchen'),
(1,'preparing','Chefs are preparing your meal'),(1,'ready','Rider on the way'),(1,'completed','Delivered. Enjoy!');

INSERT INTO reservations (reference, user_id, name, email, phone, reservation_date, reservation_time, party_size, special_requests, status)
VALUES ('RS-DEMO01', 2, 'Maria Santos', 'customer@aurumkitchen.test', '+63 900 000 0002',
  DATE_ADD(CURDATE(), INTERVAL 7 DAY), '19:00:00', 4, 'Window table, anniversary dinner.', 'confirmed');

INSERT INTO reviews (product_id, user_id, rating, comment) VALUES
(5, 2, 5, 'Fall-apart tender and the peanut sauce is unreal.'),
(10, 2, 5, 'Best ube dessert I have ever had.');
