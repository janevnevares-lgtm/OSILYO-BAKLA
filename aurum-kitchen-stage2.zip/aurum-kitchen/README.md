# Aurum Kitchen — Restaurant Ordering Website

PHP 8.1+ · MySQL (PDO) · Tailwind CSS (CDN) · vanilla JS (+ GSAP via CDN)

## Build status
| Stage | Contents | Status |
|-------|----------|--------|
| 1 | Structure, database, config, shared layout, cinematic CSS/JS | ✅ Done |
| 2 | Home, login/register/logout, menu, product details | ✅ Done |
| 3 | Cart, checkout, order tracking | ⏳ Next |
| 4 | Reservations, profile, print / PDF / Excel exports | ⏳ |
| 5 | Admin dashboard | ⏳ |

## Setup (XAMPP / Laragon)
1. Copy the `aurum-kitchen` folder into `htdocs` (XAMPP) or `www` (Laragon).
2. Start Apache and MySQL.
3. Import the database:
   - phpMyAdmin → *Import* → choose `database.sql`, **or**
   - `mysql -u root -p < database.sql`
4. Open `config/config.php` and check:
   - `BASE_URL` — `'/aurum-kitchen'` if served from a sub-folder, `''` if from the web root
   - `DB_USER` / `DB_PASS` for your MySQL install
5. Browse to `http://localhost/aurum-kitchen/`.
6. *(Stages 4–5)* Run `composer install` in the project root for Dompdf and PhpSpreadsheet.

## Demo accounts
| Role | Email | Password |
|------|-------|----------|
| Admin | admin@aurumkitchen.test | `Admin@123` |
| Customer | customer@aurumkitchen.test | `Customer@123` |

Promo codes: `WELCOME10` (10% off ₱500+), `AURUM100` (₱100 off ₱1,000+).
Sample order to try tracking and receipts: `AK-DEMO-0001`.
Change the demo passwords before going live.

## Structure
```
config/     config.php (settings, secure session) · db.php (PDO)
includes/   header.php · footer.php · auth.php · functions.php
assets/     css/style.css · css/print.css · js/app.js · images/
api/        favorite.php (done) · cart / orders / tracking / reservations — later stages
admin/      dashboard — Stage 5
exports/    PDF / Excel generators — Stage 4
database.sql
```

## Front-end API (`window.AK`)
`AK.toast(msg, type)` · `AK.Cart.add/remove/setQty/clear` · `AK.api(path, {method, data})` · `AK.flyToCart(imgEl)` · `AK.revealNew(root)`.
Any button with `data-add-to-cart data-id data-name data-price data-image` inside a `[data-product-card]` works automatically (fly-to-cart, badge bump, toast).

## Security notes
Prepared statements everywhere, `htmlspecialchars` output helper `e()`, CSRF tokens, `session_regenerate_id` on login, failed-login rate limiting (5 attempts / 15 min), upload MIME + size validation, role checks via `require_admin()`.
Set `APP_DEBUG` to `false` in production and serve over HTTPS.

## Optional: hero video
Drop a looping, muted clip at `assets/video/hero.mp4` and the home hero will use it on desktop automatically.
