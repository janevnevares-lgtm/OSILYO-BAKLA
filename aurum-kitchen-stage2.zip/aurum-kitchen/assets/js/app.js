/* ============================================================
   Aurum Kitchen — shared front-end behaviour
   Exposes a small global: window.AK
   ============================================================ */
(() => {
  'use strict';

  const $  = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];
  const body = document.body;
  const BASE = body.dataset.base || '';
  const CUR  = body.dataset.currency || '₱';
  const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const finePointer  = matchMedia('(hover: hover) and (pointer: fine)').matches;

  const fmt = n => CUR + Number(n).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  /* ---------- Toasts ---------- */
  function toast(message, type = 'info', ms = 3600) {
    const wrap = $('#toasts');
    if (!wrap) return;
    const el = document.createElement('div');
    el.className = `toast toast--${type}`;
    el.textContent = message;
    wrap.appendChild(el);
    setTimeout(() => { el.classList.add('is-leaving'); setTimeout(() => el.remove(), 450); }, ms);
  }
  $$('[data-flash]').forEach(el => setTimeout(() => { el.classList.add('is-leaving'); setTimeout(() => el.remove(), 450); }, 5000));

  /* ---------- Intro curtain (once per session) ---------- */
  const intro = $('#intro');
  if (intro) {
    if (sessionStorage.getItem('ak-intro') || reduceMotion) {
      intro.remove();
    } else {
      setTimeout(() => { intro.classList.add('is-done'); sessionStorage.setItem('ak-intro', '1'); }, 1900);
      setTimeout(() => intro.remove(), 3200);
    }
  }

  /* ---------- Smooth page transitions ---------- */
  const curtain = $('#page-curtain');
  document.addEventListener('click', e => {
    const a = e.target.closest('a[data-transition]');
    if (!a || e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || a.target === '_blank') return;
    const href = a.getAttribute('href');
    if (!href || href.startsWith('#') || reduceMotion || !curtain) return;
    e.preventDefault();
    curtain.classList.add('is-active');
    setTimeout(() => { location.href = href; }, 550);
  });
  window.addEventListener('pageshow', e => { if (e.persisted && curtain) curtain.classList.remove('is-active'); });

  /* ---------- Navbar scroll state ---------- */
  const navbar = $('#navbar');
  const onScroll = () => navbar && navbar.classList.toggle('is-scrolled', scrollY > 40);
  addEventListener('scroll', onScroll, { passive: true }); onScroll();

  /* ---------- Mobile menu ---------- */
  const menuBtn = $('#menu-toggle'), menu = $('#mobile-menu');
  menuBtn?.addEventListener('click', () => {
    const open = menuBtn.getAttribute('aria-expanded') === 'true';
    menuBtn.setAttribute('aria-expanded', String(!open));
    menu.hidden = open;
    body.style.overflow = open ? '' : 'hidden';
  });

  /* ---------- User dropdown ---------- */
  const uBtn = $('#user-menu-btn'), uPanel = $('#user-menu-panel');
  if (uBtn && uPanel) {
    const setUser = open => {
      uBtn.setAttribute('aria-expanded', String(open));
      uPanel.classList.toggle('invisible', !open);
      uPanel.classList.toggle('opacity-0', !open);
      uPanel.classList.toggle('translate-y-2', !open);
    };
    uBtn.addEventListener('click', e => { e.stopPropagation(); setUser(uBtn.getAttribute('aria-expanded') !== 'true'); });
    document.addEventListener('click', e => { if (!uPanel.contains(e.target)) setUser(false); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') setUser(false); });
  }

  /* ---------- Scroll reveals ---------- */
  const revealEls = $$('[data-reveal], .split-line');
  if ('IntersectionObserver' in window && !reduceMotion) {
    const io = new IntersectionObserver(entries => {
      entries.forEach(en => { if (en.isIntersecting) { en.target.classList.add('is-in'); io.unobserve(en.target); } });
    }, { threshold: 0.15, rootMargin: '0px 0px -8% 0px' });
    revealEls.forEach(el => io.observe(el));
  } else {
    revealEls.forEach(el => el.classList.add('is-in'));
  }
  // Stagger siblings that opt-in with data-stagger on the parent
  $$('[data-stagger]').forEach(parent => {
    [...parent.children].forEach((child, i) => child.style.setProperty('--d', `${i * 0.09}s`));
  });
  // Re-run after dynamic content (e.g. menu filtering) is injected
  function revealNew(root = document) {
    $$('[data-reveal]:not(.is-in)', root).forEach((el, i) => {
      el.style.setProperty('--d', `${Math.min(i, 8) * 0.06}s`);
      requestAnimationFrame(() => el.classList.add('is-in'));
    });
  }

  /* ---------- Parallax (GSAP optional, CSS fallback) ---------- */
  function initGsap() {
    if (!window.gsap || !window.ScrollTrigger || reduceMotion) return;
    gsap.registerPlugin(ScrollTrigger);
    $$('[data-parallax]').forEach(el => {
      const speed = parseFloat(el.dataset.parallax) || 0.2;
      gsap.to(el, { yPercent: speed * 100, ease: 'none',
        scrollTrigger: { trigger: el.parentElement, start: 'top bottom', end: 'bottom top', scrub: true } });
    });
    document.dispatchEvent(new CustomEvent('ak:gsap-ready'));
  }
  window.addEventListener('load', initGsap);

  /* ---------- Custom cursor + magnetic buttons ---------- */
  const cursor = $('#cursor');
  if (cursor && finePointer && !reduceMotion) {
    body.classList.add('has-cursor');
    let x = 0, y = 0, cx = 0, cy = 0;
    addEventListener('mousemove', e => { x = e.clientX; y = e.clientY; cursor.classList.add('is-visible'); });
    document.addEventListener('mouseleave', () => cursor.classList.remove('is-visible'));
    (function loop() {
      cx += (x - cx) * 0.2; cy += (y - cy) * 0.2;
      cursor.style.transform = `translate3d(${cx}px, ${cy}px, 0)`;
      requestAnimationFrame(loop);
    })();
    document.addEventListener('mouseover', e => {
      cursor.classList.toggle('is-hover', !!e.target.closest('a, button, [data-hover], input, select, textarea, label'));
    });

    document.addEventListener('mousemove', e => {
      $$('.magnetic').forEach(btn => {
        const r = btn.getBoundingClientRect();
        const dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2);
        if (Math.hypot(dx, dy) < 90) btn.style.transform = `translate(${dx * 0.25}px, ${dy * 0.25}px)`;
        else if (btn.style.transform) btn.style.transform = '';
      });
    }, { passive: true });
  }

  /* ---------- CSRF + fetch helper ---------- */
  const csrf = () => document.querySelector('meta[name="csrf-token"]')?.content || '';
  async function api(path, { method = 'GET', data } = {}) {
    const opts = { method, headers: { 'X-CSRF-Token': csrf(), 'Accept': 'application/json' }, credentials: 'same-origin' };
    if (data !== undefined) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(data); }
    const res = await fetch(`${BASE}/api/${path}`, opts);
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(json.error || 'Something went wrong. Please try again.');
    return json;
  }

  /* ============================================================
     CART — localStorage store (guests). Stage 3 adds server sync
     for logged-in users through /api/cart.php using the same shape.
     Item: { key, id, name, price, qty, image, options:[{id,name,delta}], notes }
     ============================================================ */
  const CART_KEY = 'ak-cart-v1';
  const Cart = {
    items() { try { return JSON.parse(localStorage.getItem(CART_KEY)) || []; } catch { return []; } },
    save(items) { localStorage.setItem(CART_KEY, JSON.stringify(items)); this.render(); document.dispatchEvent(new CustomEvent('ak:cart-changed', { detail: items })); },
    keyFor(item) { return [item.id, (item.options || []).map(o => o.id).sort().join('-'), item.notes || ''].join('|'); },
    unitPrice(it) { return Number(it.price) + (it.options || []).reduce((s, o) => s + Number(o.delta || 0), 0); },
    count() { return this.items().reduce((s, i) => s + i.qty, 0); },
    subtotal() { return this.items().reduce((s, i) => s + this.unitPrice(i) * i.qty, 0); },
    add(item) {
      const items = this.items();
      item.key = this.keyFor(item);
      const existing = items.find(i => i.key === item.key);
      if (existing) existing.qty += item.qty || 1; else items.push({ ...item, qty: item.qty || 1 });
      this.save(items);
      const badge = $('#cart-badge'); badge?.classList.remove('bump'); void badge?.offsetWidth; badge?.classList.add('bump');
    },
    setQty(key, qty) {
      const items = this.items().map(i => i.key === key ? { ...i, qty } : i).filter(i => i.qty > 0);
      this.save(items);
    },
    remove(key) { this.save(this.items().filter(i => i.key !== key)); },
    clear() { this.save([]); },
    render() {
      const items = this.items();
      const badge = $('#cart-badge');
      if (badge) { badge.dataset.count = this.count(); badge.textContent = this.count(); }
      const list = $('#mini-cart-items'), sub = $('#mini-cart-subtotal');
      if (!list) return;
      sub && (sub.textContent = fmt(this.subtotal()));
      if (!items.length) {
        list.innerHTML = `<div class="grid h-full place-content-center gap-3 py-20 text-center text-ivory/50">
          <p class="font-serif text-3xl text-ivory/80">Your cart is empty</p>
          <p>Add something delicious from the menu.</p>
          <a href="${BASE}/menu.php" class="btn-gold mx-auto mt-4">Browse menu</a></div>`;
        return;
      }
      list.innerHTML = items.map(i => `
        <div class="flex gap-4 border-b border-white/5 py-4" data-key="${esc(i.key)}">
          <img src="${esc(i.image)}" alt="" class="h-20 w-20 flex-none rounded-xl object-cover" loading="lazy">
          <div class="min-w-0 flex-1">
            <p class="truncate font-serif text-xl">${esc(i.name)}</p>
            ${i.options?.length ? `<p class="truncate text-xs text-ivory/50">${esc(i.options.map(o => o.name).join(', '))}</p>` : ''}
            <p class="mt-1 text-sm text-gold">${fmt(this.unitPrice(i))}</p>
            <div class="mt-2 flex items-center gap-3">
              <button data-act="dec" class="grid h-7 w-7 place-items-center rounded-full border border-white/20 hover:border-gold" aria-label="Decrease quantity">−</button>
              <span class="w-5 text-center text-sm">${i.qty}</span>
              <button data-act="inc" class="grid h-7 w-7 place-items-center rounded-full border border-white/20 hover:border-gold" aria-label="Increase quantity">+</button>
              <button data-act="rm" class="ml-auto text-xs text-rose-300 hover:underline">Remove</button>
            </div>
          </div>
        </div>`).join('');
    },
  };

  /* Mini-cart open / close */
  const drawer = $('#mini-cart'), overlay = $('#cart-overlay'), cartBtn = $('#cart-btn');
  function openCart() {
    Cart.render();
    drawer.classList.add('is-open'); drawer.setAttribute('aria-hidden', 'false');
    overlay.hidden = false; cartBtn.setAttribute('aria-expanded', 'true'); body.style.overflow = 'hidden';
    $('#cart-close')?.focus();
  }
  function closeCart() {
    drawer.classList.remove('is-open'); drawer.setAttribute('aria-hidden', 'true');
    overlay.hidden = true; cartBtn.setAttribute('aria-expanded', 'false'); body.style.overflow = '';
  }
  cartBtn?.addEventListener('click', openCart);
  $('#cart-close')?.addEventListener('click', closeCart);
  overlay?.addEventListener('click', closeCart);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeCart(); });
  drawer?.addEventListener('click', e => {
    const btn = e.target.closest('[data-act]'); if (!btn) return;
    const key = btn.closest('[data-key]').dataset.key;
    const item = Cart.items().find(i => i.key === key); if (!item) return;
    if (btn.dataset.act === 'inc') Cart.setQty(key, item.qty + 1);
    if (btn.dataset.act === 'dec') Cart.setQty(key, item.qty - 1);
    if (btn.dataset.act === 'rm')  Cart.remove(key);
  });

  /* Fly-to-cart animation */
  function flyToCart(imgEl) {
    if (!imgEl || reduceMotion || !cartBtn) return;
    const from = imgEl.getBoundingClientRect(), to = cartBtn.getBoundingClientRect();
    const clone = document.createElement('img');
    clone.src = imgEl.currentSrc || imgEl.src; clone.className = 'fly';
    Object.assign(clone.style, { left: from.left + 'px', top: from.top + 'px', width: from.width + 'px', height: from.height + 'px' });
    document.body.appendChild(clone);
    requestAnimationFrame(() => {
      const dx = to.left + to.width / 2 - (from.left + from.width / 2), dy = to.top + to.height / 2 - (from.top + from.height / 2);
      clone.style.transform = `translate(${dx}px, ${dy}px) scale(.08)`; clone.style.opacity = '.4';
    });
    setTimeout(() => clone.remove(), 900);
  }

  /* Declarative add-to-cart buttons:
     <button data-add-to-cart data-id data-name data-price data-image> */
  document.addEventListener('click', e => {
    const btn = e.target.closest('[data-add-to-cart]'); if (!btn) return;
    e.preventDefault();
    const d = btn.dataset;
    Cart.add({ id: +d.id, name: d.name, price: +d.price, image: d.image, qty: 1, options: [], notes: '' });
    flyToCart(btn.closest('[data-product-card]')?.querySelector('img'));
    toast(`${d.name} added to your cart`, 'success');
  });

  /* ---------- Favorites (heart buttons) ---------- */
  document.addEventListener('click', async e => {
    const btn = e.target.closest('[data-fav]'); if (!btn) return;
    e.preventDefault();
    try {
      const res = await api('favorite.php', { method: 'POST', data: { product_id: +btn.dataset.fav } });
      btn.setAttribute('aria-pressed', String(res.favorited));
      const svg = btn.querySelector('svg');
      svg?.classList.toggle('fill-gold', res.favorited); svg?.classList.toggle('text-gold', res.favorited);
      svg?.classList.toggle('fill-transparent', !res.favorited); svg?.classList.toggle('text-ivory', !res.favorited);
      toast(res.favorited ? 'Saved to your favorites' : 'Removed from favorites', 'success');
    } catch (err) {
      toast(err.message, 'info');
    }
  });

  /* ---------- Broken image fallback ---------- */
  document.addEventListener('error', e => {
    const img = e.target;
    if (img.tagName === 'IMG' && !img.dataset.failed) { img.dataset.failed = '1'; img.classList.add('img-fallback'); img.removeAttribute('srcset'); img.src = 'data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%221%22 height=%221%22/>'; }
  }, true);

  Cart.render();
  addEventListener('storage', e => { if (e.key === CART_KEY) Cart.render(); });

  /* ---------- Public API ---------- */
  window.AK = { $, $$, esc, fmt, toast, api, csrf, Cart, flyToCart, revealNew, openCart, closeCart, reduceMotion };
})();
