/* Menu page: category tabs, live search, price + dietary filters, sorting */
(() => {
  'use strict';
  const app = document.getElementById('menu-app');
  if (!app) return;

  const $  = (s, c = app) => c.querySelector(s);
  const $$ = (s, c = app) => [...c.querySelectorAll(s)];

  const grid = $('#menu-grid'), skeleton = $('#menu-skeleton'), empty = $('#menu-empty');
  const search = $('#menu-search'), price = $('#menu-price'), priceOut = $('#menu-price-out');
  const sort = $('#menu-sort'), countEl = $('#menu-count'), reset = $('#menu-reset');
  const cards = $$('[data-product-card]', grid);
  const maxPrice = +app.dataset.maxPrice;
  const peso = n => '₱' + Number(n).toLocaleString('en-PH', { minimumFractionDigits: 2 });

  let isReady = false;
  const state = { cat: app.dataset.initialCat || 'all', q: '', max: maxPrice, tags: new Set(), sort: 'featured' };
  if (!$(`.cat-tab[data-cat="${state.cat}"]`)) state.cat = 'all';

  function apply() {
    const q = state.q.trim().toLowerCase();
    let visible = [];

    cards.forEach(card => {
      const d = card.dataset;
      const tags = d.tags.split(',').map(t => t.trim());
      const ok =
        (state.cat === 'all' || d.cat === state.cat) &&
        (!q || d.name.includes(q)) &&
        (+d.price <= state.max) &&
        [...state.tags].every(t => tags.includes(t));
      card.classList.toggle('is-hidden', !ok);
      if (ok) visible.push(card);
    });

    // Sort (re-append in order; hidden cards stay at the end)
    const by = {
      'featured':   (a, b) => a.dataset.order - b.dataset.order,
      'price-asc':  (a, b) => a.dataset.price - b.dataset.price,
      'price-desc': (a, b) => b.dataset.price - a.dataset.price,
      'rating':     (a, b) => b.dataset.rating - a.dataset.rating,
      'name':       (a, b) => a.querySelector('h3').textContent.localeCompare(b.querySelector('h3').textContent),
    }[state.sort];
    visible.sort(by).forEach(c => grid.appendChild(c));
    cards.filter(c => !visible.includes(c)).forEach(c => grid.appendChild(c));

    // Re-trigger the entrance animation for what's showing
    visible.forEach((c, i) => {
      c.classList.remove('is-in');
      c.style.setProperty('--d', `${Math.min(i, 8) * 0.05}s`);
    });
    requestAnimationFrame(() => requestAnimationFrame(() => visible.forEach(c => c.classList.add('is-in'))));

    empty.classList.toggle('hidden', visible.length > 0);
    if (isReady) grid.classList.toggle('hidden', visible.length === 0);
    countEl.textContent = `${visible.length} ${visible.length === 1 ? 'dish' : 'dishes'}`;
    const dirty = state.q || state.max < maxPrice || state.tags.size || state.cat !== 'all' || state.sort !== 'featured';
    reset.classList.toggle('hidden', !dirty);
  }

  /* Category tabs (with arrow-key navigation) */
  const tabs = $$('.cat-tab');
  const setCat = slug => {
    state.cat = slug;
    tabs.forEach(t => { t.setAttribute('aria-selected', String(t.dataset.cat === slug)); t.tabIndex = t.dataset.cat === slug ? 0 : -1; });
    apply();
  };
  tabs.forEach((t, i) => {
    t.addEventListener('click', () => setCat(t.dataset.cat));
    t.addEventListener('keydown', e => {
      const next = e.key === 'ArrowRight' ? tabs[(i + 1) % tabs.length] : e.key === 'ArrowLeft' ? tabs[(i - 1 + tabs.length) % tabs.length] : null;
      if (next) { e.preventDefault(); next.focus(); next.click(); }
    });
  });

  /* Live search (debounced) */
  let timer;
  search.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(() => { state.q = search.value; apply(); }, 120); });

  /* Price */
  price.addEventListener('input', () => { state.max = +price.value; priceOut.textContent = peso(state.max); apply(); });

  /* Dietary chips */
  $$('.chip').forEach(chip => chip.addEventListener('click', () => {
    const on = chip.getAttribute('aria-pressed') !== 'true';
    chip.setAttribute('aria-pressed', String(on));
    on ? state.tags.add(chip.dataset.tag) : state.tags.delete(chip.dataset.tag);
    apply();
  }));

  /* Sort */
  sort.addEventListener('change', () => { state.sort = sort.value; apply(); });

  /* Reset */
  reset.addEventListener('click', () => {
    state.q = ''; state.max = maxPrice; state.tags.clear(); state.sort = 'featured';
    search.value = ''; price.value = maxPrice; priceOut.textContent = peso(maxPrice); sort.value = 'featured';
    $$('.chip').forEach(c => c.setAttribute('aria-pressed', 'false'));
    setCat('all');
  });

  /* Initial render: show skeletons for a moment so the entrance feels cinematic */
  setCat(state.cat);
  const ready = () => { isReady = true; skeleton.remove(); apply(); };
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  reduce ? ready() : setTimeout(ready, 450);
})();
