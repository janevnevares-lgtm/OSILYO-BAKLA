/* Product page: gallery, option pricing, quantity, add to cart */
(() => {
  'use strict';
  const form = document.getElementById('product-form');
  if (!form) return;

  const main = document.getElementById('main-image');
  const qtyEl = document.getElementById('qty'), totalEl = document.getElementById('total');
  const base = +form.dataset.price;
  let qty = 1;

  /* Gallery */
  document.querySelectorAll('[data-thumb]').forEach(btn => btn.addEventListener('click', () => {
    main.style.opacity = '0';
    setTimeout(() => { main.src = btn.dataset.thumb; main.style.opacity = '1'; }, 180);
    main.style.transition = 'opacity .25s';
    document.querySelectorAll('[data-thumb]').forEach(b => { b.classList.toggle('border-gold', b === btn); b.classList.toggle('border-white/10', b !== btn); });
  }));

  /* Selected options */
  const selected = () => [...form.querySelectorAll('input[name="size"]:checked, input[name="addon"]:checked')]
    .map(i => ({ id: +i.value, name: i.dataset.name, delta: +i.dataset.delta }));
  const unit = () => base + selected().reduce((s, o) => s + o.delta, 0);

  const refresh = () => {
    qtyEl.textContent = qty;
    totalEl.textContent = AK.fmt(unit() * qty);
  };
  form.addEventListener('change', refresh);
  document.getElementById('qty-inc').addEventListener('click', () => { qty = Math.min(qty + 1, 20); refresh(); });
  document.getElementById('qty-dec').addEventListener('click', () => { qty = Math.max(qty - 1, 1); refresh(); });

  /* Add to cart */
  document.getElementById('add-btn').addEventListener('click', () => {
    const options = selected();
    // The "Regular" size has a 0 delta; keep only meaningful labels in the cart line
    AK.Cart.add({
      id: +form.dataset.id, name: form.dataset.name, price: base, image: form.dataset.image,
      qty, options, notes: document.getElementById('notes').value.trim().slice(0, 200),
    });
    AK.flyToCart(main);
    AK.toast(`${qty} × ${form.dataset.name} added to your cart`, 'success');
    qty = 1; refresh();
    setTimeout(() => AK.openCart(), 900);
  });

  refresh();
})();
