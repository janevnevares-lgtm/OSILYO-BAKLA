/* Login / register helpers: show-hide password, strength meter, client-side validation */
(() => {
  'use strict';

  document.querySelectorAll('[data-toggle-password]').forEach(btn => {
    btn.addEventListener('click', () => {
      const input = document.getElementById(btn.dataset.togglePassword);
      const show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.textContent = show ? 'Hide' : 'Show';
      btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    });
  });

  const pw = document.getElementById('password'), meter = document.getElementById('pw-meter');
  if (pw && meter) {
    pw.addEventListener('input', () => {
      const v = pw.value;
      let score = 0;
      if (v.length >= 8) score++;
      if (/[A-Z]/.test(v) && /[a-z]/.test(v)) score++;
      if (/\d/.test(v)) score++;
      if (/[^A-Za-z0-9]/.test(v) || v.length >= 12) score++;
      meter.style.width = (score * 25) + '%';
      meter.style.background = ['#fb7185', '#fb7185', '#fbbf24', '#34d399', '#C9A24B'][score];
    });
  }

  // Lightweight inline validation (the server always re-validates)
  document.querySelectorAll('form[data-validate]').forEach(form => {
    form.addEventListener('submit', e => {
      form.querySelectorAll('.js-error').forEach(n => n.remove());
      let ok = true;
      const fail = (input, msg) => {
        ok = false;
        const p = document.createElement('p');
        p.className = 'field-error js-error'; p.textContent = msg;
        (input.closest('div:not(.relative)') || input.parentElement).appendChild(p);
      };
      form.querySelectorAll('[required]').forEach(input => {
        if (!input.value.trim()) fail(input, 'This field is required.');
        else if (input.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value)) fail(input, 'Enter a valid email address.');
      });
      const p1 = form.querySelector('#password'), p2 = form.querySelector('#password_confirm');
      if (p1 && p2 && p1.value && p1.value !== p2.value) fail(p2, 'Passwords do not match.');
      if (!ok) { e.preventDefault(); form.querySelector('.js-error')?.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
    });
  });
})();
