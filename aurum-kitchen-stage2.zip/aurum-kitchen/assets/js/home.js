/* Home page behaviour: carousel arrows, count-up numbers, pinned horizontal scroll */
(() => {
  'use strict';
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---- Featured carousel arrows ---- */
  const row = document.getElementById('featured-row');
  if (row) {
    const step = () => Math.max(row.clientWidth * 0.8, 300);
    document.querySelector('[data-carousel-prev]')?.addEventListener('click', () => row.scrollBy({ left: -step(), behavior: 'smooth' }));
    document.querySelector('[data-carousel-next]')?.addEventListener('click', () => row.scrollBy({ left: step(), behavior: 'smooth' }));
    row.addEventListener('keydown', e => {
      if (e.key === 'ArrowRight') row.scrollBy({ left: step(), behavior: 'smooth' });
      if (e.key === 'ArrowLeft')  row.scrollBy({ left: -step(), behavior: 'smooth' });
    });
  }

  /* ---- Count-up numbers ---- */
  const counters = document.querySelectorAll('[data-count]');
  const run = el => {
    const target = +el.dataset.count, suffix = el.dataset.suffix || '';
    if (reduce) { el.textContent = target + suffix; return; }
    const t0 = performance.now(), dur = 1600;
    const tick = now => {
      const p = Math.min((now - t0) / dur, 1), eased = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(target * eased) + suffix;
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  };
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver(es => es.forEach(en => { if (en.isIntersecting) { run(en.target); io.unobserve(en.target); } }), { threshold: .6 });
    counters.forEach(c => io.observe(c));
  } else counters.forEach(run);

  /* ---- Pinned horizontal scroll (desktop only; mobile keeps native swipe) ---- */
  const section = document.getElementById('signature');
  if (!section || reduce) return;

  const setup = () => {
    if (!window.gsap || !window.ScrollTrigger || innerWidth < 1024) return;
    gsap.registerPlugin(ScrollTrigger);
    const viewport = section.querySelector('.hscroll__viewport');
    const track = section.querySelector('.hscroll__track');
    viewport.classList.add('is-pinned');
    const distance = () => Math.max(track.scrollWidth - viewport.clientWidth, 0);
    gsap.to(track, {
      x: () => -distance(), ease: 'none',
      scrollTrigger: { trigger: section, start: 'top 8%', end: () => '+=' + distance(), pin: true, scrub: 1, invalidateOnRefresh: true, anticipatePin: 1 },
    });
  };
  window.addEventListener('load', setup);
})();
