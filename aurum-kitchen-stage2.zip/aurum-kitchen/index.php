<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/components.php';

$user   = current_user();
$favIds = user_favorite_ids($user['id'] ?? null);

$featured = db()->query(
    'SELECT p.*, c.slug AS category_slug
       FROM products p JOIN categories c ON c.id = p.category_id
      WHERE p.is_featured = 1 AND p.is_available = 1
      ORDER BY p.rating DESC, p.id LIMIT 8'
)->fetchAll();

$signature = array_slice($featured, 0, 4);

$testimonials = [
    ['“The kare-kare alone is worth the trip. Tender, deep, and plated like art.”', 'Isabel R.', 'Food blogger'],
    ['“Ordering online was effortless and the tracking page made the wait part of the fun.”', 'Miguel T.', 'Regular guest'],
    ['“We celebrated our anniversary here. The service, the lighting, the ube cheesecake — flawless.”', 'Anna & Paolo', 'Reserved for two'],
];

$gallery = [
    'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=900&q=70',
    'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=900&q=70',
    'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?auto=format&fit=crop&w=900&q=70',
    'https://images.unsplash.com/photo-1544148103-0773bf10d330?auto=format&fit=crop&w=900&q=70',
    'https://images.unsplash.com/photo-1559339352-11d035aa65de?auto=format&fit=crop&w=900&q=70',
    'https://images.unsplash.com/photo-1599084993091-1cb5c0721cc6?auto=format&fit=crop&w=900&q=70',
];

$pageTitle = 'Modern Filipino Fine Dining';
require_once __DIR__ . '/includes/header.php';
?>

<!-- ============ HERO ============ -->
<section class="relative isolate flex min-h-screen items-center justify-center overflow-hidden" aria-label="Welcome">
  <?php if (file_exists(__DIR__ . '/assets/video/hero.mp4')): ?>
  <video class="absolute inset-0 -z-10 hidden h-full w-full object-cover md:block" autoplay muted loop playsinline preload="metadata"
         poster="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=1920&q=70">
    <source src="<?= url('assets/video/hero.mp4') ?>" type="video/mp4">
  </video>
  <?php endif; /* Drop a looping clip at assets/video/hero.mp4 to enable the video hero */ ?>
  <img src="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=1920&q=70" alt=""
       class="ken-burns absolute inset-0 -z-20 h-full w-full object-cover">
  <div class="hero-overlay absolute inset-0 -z-10"></div>

  <div class="px-6 text-center">
    <p class="eyebrow" data-reveal><?= e(APP_TAGLINE) ?></p>
    <h1 class="mt-6 font-serif text-6xl font-medium leading-[.95] sm:text-7xl md:text-9xl">
      <span class="split-line"><span>Taste the</span></span>
      <span class="split-line"><span class="text-gold-gradient italic">golden hour</span></span>
    </h1>
    <p class="mx-auto mt-8 max-w-xl text-lg text-ivory/70" data-reveal style="--d:.4s">
      Heritage recipes, reimagined with fire, patience and the finest ingredients from across the islands.
    </p>
    <div class="mt-10 flex flex-wrap justify-center gap-4" data-reveal style="--d:.6s">
      <a href="<?= url('menu.php') ?>" data-transition class="btn-gold magnetic">Order now</a>
      <a href="<?= url('reservations.php') ?>" data-transition class="btn-ghost magnetic">Reserve a table</a>
    </div>
  </div>

  <a href="#featured" class="absolute bottom-8 left-1/2 -translate-x-1/2 text-ivory/60 hover:text-gold" aria-label="Scroll to featured dishes">
    <span class="grid h-12 w-7 justify-center rounded-full border border-current pt-2"><span class="h-2 w-1 animate-bounce rounded bg-current"></span></span>
  </a>
</section>

<!-- ============ MARQUEE ============ -->
<div class="overflow-hidden border-y border-white/10 bg-coal py-5" aria-hidden="true">
  <div class="marquee font-serif text-3xl italic text-ivory/40">
    <?php for ($i = 0; $i < 2; $i++): ?>
      <span>Fire &amp; Patience</span><span class="text-gold">✦</span><span>Heritage Recipes</span><span class="text-gold">✦</span>
      <span>Island Ingredients</span><span class="text-gold">✦</span><span>Made to Share</span><span class="text-gold">✦</span>
    <?php endfor; ?>
  </div>
</div>

<!-- ============ FEATURED CAROUSEL ============ -->
<section id="featured" class="mx-auto max-w-7xl px-5 pt-28 md:px-8">
  <div class="flex flex-wrap items-end justify-between gap-6">
    <div data-reveal>
      <p class="eyebrow">Featured dishes</p>
      <h2 class="mt-3 font-serif text-5xl md:text-6xl">Chef's <span class="italic text-gold">selection</span></h2>
    </div>
    <div class="flex gap-3" data-reveal>
      <button class="grid h-12 w-12 place-items-center rounded-full border border-white/20 hover:border-gold hover:text-gold" data-carousel-prev aria-label="Previous dishes">←</button>
      <button class="grid h-12 w-12 place-items-center rounded-full border border-white/20 hover:border-gold hover:text-gold" data-carousel-next aria-label="Next dishes">→</button>
    </div>
  </div>

  <div class="snap-row mt-12" id="featured-row" tabindex="0" aria-label="Featured dishes">
    <?php foreach ($featured as $i => $p): ?>
      <div class="w-[78vw] sm:w-[340px]"><?= product_card($p, $favIds, $i) ?></div>
    <?php endforeach; ?>
  </div>
</section>

<!-- ============ OUR STORY ============ -->
<section class="mx-auto mt-32 grid max-w-7xl items-center gap-16 px-5 md:px-8 lg:grid-cols-2" id="story">
  <div class="relative" data-reveal="left">
    <div class="aspect-[4/5] overflow-hidden rounded-[2rem]">
      <img data-parallax="0.12" src="https://images.unsplash.com/photo-1559339352-11d035aa65de?auto=format&fit=crop&w=1100&q=70"
           alt="Chef plating a dish" loading="lazy" class="h-[115%] w-full object-cover">
    </div>
    <div class="absolute -bottom-8 -right-4 hidden rounded-2xl border border-gold/30 bg-ink/80 p-6 backdrop-blur md:block">
      <p class="font-serif text-5xl text-gold" data-count="12">0</p>
      <p class="text-xs uppercase tracking-[.25em] text-ivory/60">Years of craft</p>
    </div>
  </div>

  <div data-reveal="right">
    <p class="eyebrow">Our story</p>
    <h2 class="mt-3 font-serif text-5xl leading-tight md:text-6xl">Grandmother's recipes, <span class="italic text-gold">refined</span></h2>
    <p class="mt-8 text-lg leading-relaxed text-ivory/70">
      We began in a small family kitchen in Quezon, where every dish was a story passed from hand to hand.
      Today we cook those same stories over live fire with line-caught seafood, heirloom rice and
      farm-to-table produce — honoring the past without being bound by it.
    </p>
    <div class="mt-10 grid grid-cols-3 gap-6 border-t border-white/10 pt-8">
      <div><p class="font-serif text-4xl text-gold" data-count="40" data-suffix="+">0</p><p class="mt-1 text-xs uppercase tracking-widest text-ivory/50">Signature dishes</p></div>
      <div><p class="font-serif text-4xl text-gold" data-count="15" data-suffix="k">0</p><p class="mt-1 text-xs uppercase tracking-widest text-ivory/50">Happy guests</p></div>
      <div><p class="font-serif text-4xl text-gold" data-count="8">0</p><p class="mt-1 text-xs uppercase tracking-widest text-ivory/50">Local partners</p></div>
    </div>
    <a href="<?= url('reservations.php') ?>" data-transition class="btn-ghost mt-10 magnetic">Book a tasting</a>
  </div>
</section>

<!-- ============ SIGNATURE (pinned horizontal scroll on desktop) ============ -->
<?php if ($signature): ?>
<section id="signature" class="hscroll mt-32 overflow-hidden" aria-label="Signature dishes">
  <div class="mx-auto max-w-7xl px-5 pb-10 md:px-8" data-reveal>
    <p class="eyebrow">Signature menu</p>
    <h2 class="mt-3 font-serif text-5xl md:text-6xl">Dishes worth <span class="italic text-gold">the journey</span></h2>
  </div>
  <div class="hscroll__viewport">
    <div class="hscroll__track">
      <?php foreach ($signature as $i => $p): ?>
        <article class="hscroll__panel">
          <div class="zoom-wrap relative h-[52vh] w-full overflow-hidden rounded-[2rem] lg:h-[62vh]">
            <img src="<?= e(image_url($p['image'])) ?>" alt="<?= e($p['name']) ?>" loading="lazy" class="h-full w-full object-cover">
            <div class="absolute inset-0 bg-gradient-to-t from-ink/90 via-transparent"></div>
            <div class="absolute inset-x-0 bottom-0 p-8">
              <p class="font-serif text-6xl text-gold/60"><?= sprintf('%02d', $i + 1) ?></p>
              <h3 class="mt-1 font-serif text-4xl md:text-5xl"><?= e($p['name']) ?></h3>
              <p class="mt-3 max-w-md text-ivory/70"><?= e($p['short_desc']) ?></p>
              <div class="mt-5 flex items-center gap-5">
                <span class="text-xl font-semibold text-gold"><?= money($p['price']) ?></span>
                <a href="<?= url('product.php?id=' . (int) $p['id']) ?>" data-transition class="btn-ghost !py-2.5">Discover</a>
              </div>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ============ TESTIMONIALS ============ -->
<section class="mx-auto mt-32 max-w-7xl px-5 md:px-8" aria-label="Guest reviews">
  <div class="text-center" data-reveal>
    <p class="eyebrow">Kind words</p>
    <h2 class="mt-3 font-serif text-5xl md:text-6xl">Loved by our <span class="italic text-gold">guests</span></h2>
  </div>
  <div class="mt-14 grid gap-6 md:grid-cols-3" data-stagger>
    <?php foreach ($testimonials as [$quote, $who, $role]): ?>
      <figure class="card p-8" data-reveal>
        <div class="text-gold" aria-hidden="true">★★★★★</div>
        <blockquote class="mt-5 font-serif text-2xl leading-snug text-ivory/90"><?= e($quote) ?></blockquote>
        <figcaption class="mt-6 text-sm"><span class="font-semibold"><?= e($who) ?></span> <span class="text-ivory/50">· <?= e($role) ?></span></figcaption>
      </figure>
    <?php endforeach; ?>
  </div>
</section>

<!-- ============ GALLERY ============ -->
<section class="mx-auto mt-32 max-w-7xl px-5 md:px-8" aria-label="Gallery">
  <div class="flex items-end justify-between" data-reveal>
    <div>
      <p class="eyebrow">Gallery</p>
      <h2 class="mt-3 font-serif text-5xl md:text-6xl">A feast for the <span class="italic text-gold">eyes</span></h2>
    </div>
  </div>
  <div class="mt-12 grid auto-rows-[200px] grid-cols-2 gap-4 md:auto-rows-[260px] md:grid-cols-4" data-stagger>
    <?php
    $spans = ['md:col-span-2 md:row-span-2', '', 'md:row-span-2', '', 'md:col-span-2', ''];
    foreach ($gallery as $i => $src): ?>
      <div class="zoom-wrap overflow-hidden rounded-2xl <?= $spans[$i] ?>" data-reveal>
        <img src="<?= e($src) ?>" alt="Aurum Kitchen gallery photo <?= $i + 1 ?>" loading="lazy" class="h-full w-full object-cover">
      </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- ============ HOURS & LOCATION ============ -->
<section class="mx-auto mt-32 grid max-w-7xl gap-8 px-5 md:px-8 lg:grid-cols-2" aria-label="Hours and location">
  <div class="card p-10" data-reveal="left">
    <p class="eyebrow">Opening hours</p>
    <ul class="mt-8 divide-y divide-white/10">
      <?php foreach ([['Tuesday – Thursday', '11:00 – 21:00'], ['Friday – Saturday', '11:00 – 22:30'], ['Sunday', '10:00 – 20:00'], ['Monday', 'Closed']] as [$d, $h]): ?>
        <li class="flex justify-between py-4"><span class="text-ivory/70"><?= e($d) ?></span><span class="<?= $h === 'Closed' ? 'text-rose-300' : 'text-gold' ?>"><?= e($h) ?></span></li>
      <?php endforeach; ?>
    </ul>
  </div>
  <div class="card flex flex-col justify-between p-10" data-reveal="right">
    <div>
      <p class="eyebrow">Find us</p>
      <p class="mt-6 font-serif text-4xl leading-tight"><?= e(APP_ADDRESS) ?></p>
      <p class="mt-4 text-ivory/60"><?= e(APP_PHONE) ?> · <?= e(APP_EMAIL) ?></p>
    </div>
    <a class="btn-ghost mt-10 w-fit" target="_blank" rel="noopener"
       href="https://www.google.com/maps/search/?api=1&query=<?= urlencode(APP_ADDRESS) ?>">Get directions ↗</a>
  </div>
</section>

<!-- ============ RESERVATION CTA ============ -->
<section class="relative mx-4 mt-32 overflow-hidden rounded-[2rem] md:mx-8">
  <img data-parallax="0.15" src="https://images.unsplash.com/photo-1514933651103-005eec06c04b?auto=format&fit=crop&w=1800&q=70" alt=""
       loading="lazy" class="absolute inset-0 h-[125%] w-full object-cover">
  <div class="absolute inset-0 bg-ink/70"></div>
  <div class="relative px-6 py-28 text-center md:py-36" data-reveal>
    <p class="eyebrow">Reservations</p>
    <h2 class="mx-auto mt-4 max-w-3xl font-serif text-5xl leading-tight md:text-7xl">Reserve your <span class="italic text-gold-gradient">evening</span></h2>
    <p class="mx-auto mt-6 max-w-lg text-ivory/70">Intimate tables, candlelight and a tasting menu that changes with the season.</p>
    <a href="<?= url('reservations.php') ?>" data-transition class="btn-gold mt-10 magnetic">Book a table</a>
  </div>
</section>

<?php
$extraScripts = [url('assets/js/home.js')];
require_once __DIR__ . '/includes/footer.php';
