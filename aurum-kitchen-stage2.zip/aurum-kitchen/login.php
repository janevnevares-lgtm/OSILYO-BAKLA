<?php
require_once __DIR__ . '/includes/auth.php';

if (is_logged_in()) {
    redirect('index.php');
}

$errors = [];
$email  = '';

/** Only allow redirects back into this site. */
function safe_intended(): string
{
    $to = $_SESSION['intended'] ?? '';
    unset($_SESSION['intended']);
    if ($to && str_starts_with($to, BASE_URL . '/') && !str_contains($to, '//', 1) && !str_contains($to, "\n")) {
        return $to;
    }
    return '';
}

if (is_post()) {
    csrf_require();
    $email    = mb_strtolower(input('email'));
    $password = $_POST['password'] ?? '';

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Enter a valid email address.';
    }
    if ($password === '') {
        $errors['password'] = 'Enter your password.';
    }

    if (!$errors) {
        if (login_throttled($email)) {
            $errors['form'] = 'Too many failed attempts. Please try again in ' . LOGIN_LOCK_MINUTES . ' minutes.';
        } else {
            $stmt = db()->prepare('SELECT id, password_hash, role FROM users WHERE email = ? AND is_active = 1');
            $stmt->execute([$email]);
            $row = $stmt->fetch();

            if ($row && password_verify($password, $row['password_hash'])) {
                clear_failed_logins($email);
                login_user((int) $row['id']);
                if (password_needs_rehash($row['password_hash'], PASSWORD_DEFAULT)) {
                    db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
                        ->execute([password_hash($password, PASSWORD_DEFAULT), $row['id']]);
                }
                flash('success', 'Welcome back.');
                $intended = safe_intended();
                if ($intended) {
                    header('Location: ' . $intended);
                    exit;
                }
                if ($row['role'] === 'admin' && file_exists(__DIR__ . '/admin/index.php')) {
                    redirect('admin/index.php');
                }
                redirect('index.php');
            }
            record_failed_login($email);
            $errors['form'] = 'Incorrect email or password.';
        }
    }
}

$pageTitle = 'Sign in';
require_once __DIR__ . '/includes/header.php';
?>
<section class="grid min-h-screen lg:grid-cols-2">
  <!-- Image side -->
  <div class="relative hidden overflow-hidden lg:block">
    <img src="https://images.unsplash.com/photo-1559339352-11d035aa65de?auto=format&fit=crop&w=1400&q=70" alt=""
         class="ken-burns absolute inset-0 h-full w-full object-cover">
    <div class="absolute inset-0 bg-gradient-to-t from-ink via-ink/40 to-ink/10"></div>
    <div class="absolute inset-x-0 bottom-0 p-14">
      <p class="eyebrow">Welcome back</p>
      <p class="mt-4 max-w-md font-serif text-5xl leading-tight">Your table is <span class="text-gold-gradient italic">waiting.</span></p>
    </div>
  </div>

  <!-- Form side -->
  <div class="flex items-center justify-center px-6 pb-16 pt-32 lg:pt-24">
    <div class="w-full max-w-md" data-reveal>
      <p class="eyebrow">Sign in</p>
      <h1 class="mt-3 font-serif text-5xl">Good to see you</h1>
      <p class="mt-3 text-ivory/60">Sign in to order, reserve and track your meals.</p>

      <?php if (!empty($errors['form'])): ?>
        <div class="mt-6 rounded-xl border border-rose-400/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-200" role="alert"><?= e($errors['form']) ?></div>
      <?php endif; ?>

      <form method="post" class="mt-8 space-y-5" novalidate data-validate>
        <?= csrf_field() ?>
        <div>
          <label class="label" for="email">Email</label>
          <input class="input" type="email" id="email" name="email" value="<?= e($email) ?>" autocomplete="email" required>
          <?php if (!empty($errors['email'])): ?><p class="field-error"><?= e($errors['email']) ?></p><?php endif; ?>
        </div>
        <div>
          <label class="label" for="password">Password</label>
          <div class="relative">
            <input class="input pr-14" type="password" id="password" name="password" autocomplete="current-password" required>
            <button type="button" data-toggle-password="password" class="absolute right-3 top-1/2 -translate-y-1/2 text-xs uppercase tracking-widest text-ivory/60 hover:text-gold" aria-label="Show password">Show</button>
          </div>
          <?php if (!empty($errors['password'])): ?><p class="field-error"><?= e($errors['password']) ?></p><?php endif; ?>
        </div>
        <button class="btn-gold w-full justify-center magnetic" type="submit">Sign in</button>
      </form>

      <p class="mt-8 text-center text-sm text-ivory/60">
        New here? <a href="<?= url('register.php') ?>" data-transition class="text-gold hover:underline">Create an account</a>
      </p>
      <p class="mt-6 rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-xs text-ivory/50">
        Demo — customer: <span class="text-ivory/80">customer@aurumkitchen.test</span> / Customer@123 ·
        admin: <span class="text-ivory/80">admin@aurumkitchen.test</span> / Admin@123
      </p>
    </div>
  </div>
</section>
<?php
$extraScripts = [url('assets/js/auth.js')];
require_once __DIR__ . '/includes/footer.php';
