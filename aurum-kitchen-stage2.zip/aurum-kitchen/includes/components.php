<?php
/**
 * Reusable UI components (returns HTML strings so markup is never duplicated).
 */
require_once __DIR__ . '/functions.php';

/** IDs of the current user's favourite products. */
function user_favorite_ids(?int $userId): array
{
    if (!$userId) {
        return [];
    }
    $stmt = db()->prepare('SELECT product_id FROM favorites WHERE user_id = ?');
    $stmt->execute([$userId]);
    return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
}

/** Render the star rating as inline SVG-free text stars. */
function stars(float $rating): string
{
    $full = (int) round($rating);
    return '<span class="text-gold" aria-hidden="true">' . str_repeat('★', $full) . '</span>'
         . '<span class="text-white/20" aria-hidden="true">' . str_repeat('★', 5 - $full) . '</span>'
         . '<span class="sr-only">' . number_format($rating, 1) . ' out of 5</span>';
}

/** Dietary tag pills for a product. */
function tag_pills(?string $tags): string
{
    $html = '';
    foreach (array_filter(array_map('trim', explode(',', (string) $tags))) as $tag) {
        $html .= '<span class="rounded-full border border-white/15 px-2.5 py-0.5 text-[10px] uppercase tracking-widest text-ivory/70">'
               . e($tag) . '</span> ';
    }
    return $html;
}

/**
 * A single product card. $p must contain the products row plus category_slug.
 */
function product_card(array $p, array $favIds = [], int $index = 0): string
{
    $isFav = in_array((int) $p['id'], $favIds, true);
    $img   = image_url($p['image']);
    $href  = url('product.php?id=' . (int) $p['id']);
    ob_start(); ?>
    <article class="group card overflow-hidden flex flex-col" data-product-card data-reveal style="--d: <?= min($index, 8) * 0.06 ?>s"
             data-name="<?= e(mb_strtolower($p['name'] . ' ' . $p['short_desc'])) ?>"
             data-price="<?= e((string) $p['price']) ?>"
             data-cat="<?= e($p['category_slug'] ?? '') ?>"
             data-tags="<?= e(mb_strtolower((string) $p['dietary_tags'])) ?>"
             data-rating="<?= e((string) $p['rating']) ?>"
             data-order="<?= (int) $index ?>">
      <div class="relative">
        <a href="<?= $href ?>" class="zoom-wrap block aspect-[4/3]" data-transition aria-label="View <?= e($p['name']) ?>">
          <img src="<?= e($img) ?>" alt="<?= e($p['name']) ?>" loading="lazy" class="h-full w-full object-cover">
        </a>
        <button type="button" data-fav="<?= (int) $p['id'] ?>" aria-pressed="<?= $isFav ? 'true' : 'false' ?>"
                aria-label="Save <?= e($p['name']) ?> to favorites"
                class="fav-btn absolute right-3 top-3 grid h-10 w-10 place-items-center rounded-full bg-ink/60 backdrop-blur hover:bg-ink/80">
          <svg class="h-5 w-5 <?= $isFav ? 'fill-gold text-gold' : 'fill-transparent text-ivory' ?>" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.6"><path d="M12 21s-7-4.6-9.3-9A5.3 5.3 0 0 1 12 6.5 5.3 5.3 0 0 1 21.3 12C19 16.4 12 21 12 21Z"/></svg>
        </button>
        <?php if (!empty($p['is_featured'])): ?>
          <span class="absolute left-3 top-3 rounded-full bg-gold px-3 py-1 text-[10px] font-semibold uppercase tracking-widest text-ink">Chef's pick</span>
        <?php endif; ?>
      </div>
      <div class="flex flex-1 flex-col p-5">
        <div class="flex items-start justify-between gap-3">
          <h3 class="font-serif text-2xl leading-tight"><a href="<?= $href ?>" data-transition class="hover:text-gold"><?= e($p['name']) ?></a></h3>
          <p class="whitespace-nowrap font-semibold text-gold"><?= money($p['price']) ?></p>
        </div>
        <p class="mt-2 line-clamp-2 text-sm text-ivory/60"><?= e($p['short_desc']) ?></p>
        <div class="mt-3 flex flex-wrap gap-1.5"><?= tag_pills($p['dietary_tags']) ?></div>
        <div class="mt-auto flex items-center justify-between pt-5">
          <span class="text-sm"><?= stars((float) $p['rating']) ?> <span class="ml-1 text-ivory/50"><?= number_format((float) $p['rating'], 1) ?></span></span>
          <button type="button" class="btn-gold !px-4 !py-2.5" data-add-to-cart
                  data-id="<?= (int) $p['id'] ?>" data-name="<?= e($p['name']) ?>"
                  data-price="<?= e((string) $p['price']) ?>" data-image="<?= e($img) ?>">
            Add +
          </button>
        </div>
      </div>
    </article>
    <?php
    return (string) ob_get_clean();
}
