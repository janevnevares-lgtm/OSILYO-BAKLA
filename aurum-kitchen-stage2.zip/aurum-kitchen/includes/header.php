<?php
/**
 * Shared header. Set $pageTitle and optionally $bodyClass / $heroPage before including.
 */
require_once __DIR__ . '/auth.php';
$user      = current_user();
$pageTitle = ($pageTitle ?? 'Welcome') . ' — ' . APP_NAME;
$bodyClass = $bodyClass ?? '';
$navLinks  = [
    'index.php'        => 'Home',
    'menu.php'         => 'Menu',
    'reservations.php' => 'Reserve',
    'track.php'        => 'Track Order',
];
$current = basename($_SERVER['SCRIPT_NAME']);
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($pageTitle) ?></title>
  <meta name="description" content="<?= e(APP_NAME) ?> — <?= e(APP_TAGLINE) ?>. Order online, reserve a table, and track your order.">
  <meta name="csrf-token" content="<?= e(csrf_token()) ?>">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400&family=Manrope:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            ink:   '#0B0B0B',
            coal:  '#141414',
            smoke: '#1E1E1E',
            gold:  { DEFAULT: '#C9A24B', light: '#E3C47A', dark: '#9C7A2E' },
            ivory: '#F5EFE6',
          },
          fontFamily: {
            serif: ['"Cormorant Garamond"', 'Georgia', 'serif'],
            sans:  ['Manrope', 'system-ui', 'sans-serif'],
          },
          letterSpacing: { widest2: '.3em' },
        }
      }
    };
  </script>
  <link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">
  <link rel="stylesheet" href="<?= url('assets/css/print.css') ?>" media="print">
</head>
<body class="bg-ink text-ivory font-sans antialiased <?= e($bodyClass) ?>"
      data-base="<?= e(BASE_URL) ?>" data-currency="<?= e(CURRENCY) ?>"
      data-logged-in="<?= $user ? '1' : '0' ?>">

  <!-- Intro curtain (page-load animation) -->
  <div id="intro" class="intro" aria-hidden="true">
    <div class="intro__brand font-serif"><?= e(APP_NAME) ?></div>
    <div class="intro__line"></div>
  </div>
  <div id="page-curtain" class="page-curtain" aria-hidden="true"></div>
  <div class="grain" aria-hidden="true"></div>
  <div id="cursor" class="cursor" aria-hidden="true"></div>

  <a href="#main" class="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-[100] focus:bg-gold focus:text-ink focus:px-4 focus:py-2 focus:rounded">Skip to content</a>

  <!-- Navbar -->
  <header id="navbar" class="navbar fixed inset-x-0 top-0 z-50">
    <nav class="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 md:px-8" aria-label="Main">
      <a href="<?= url('index.php') ?>" class="font-serif text-2xl md:text-3xl tracking-wide text-ivory" data-transition>
        <span class="text-gold">A</span>urum <span class="hidden sm:inline text-ivory/70 italic">Kitchen</span>
      </a>

      <ul class="hidden items-center gap-9 md:flex">
        <?php foreach ($navLinks as $file => $label): ?>
          <li>
            <a href="<?= url($file) ?>" data-transition
               class="nav-link text-xs uppercase tracking-[.25em] <?= $current === $file ? 'is-active text-gold' : 'text-ivory/80 hover:text-gold' ?>">
              <?= e($label) ?>
            </a>
          </li>
        <?php endforeach; ?>
      </ul>

      <div class="flex items-center gap-3 md:gap-4">
        <?php if ($user): ?>
          <div class="relative hidden md:block" id="user-menu">
            <button class="flex items-center gap-2 text-xs uppercase tracking-[.2em] text-ivory/80 hover:text-gold"
                    aria-haspopup="true" aria-expanded="false" id="user-menu-btn">
              <span class="grid h-8 w-8 place-items-center rounded-full border border-gold/50 text-gold font-semibold">
                <?= e(strtoupper(mb_substr($user['name'], 0, 1))) ?>
              </span>
              <span class="max-w-[8rem] truncate"><?= e(explode(' ', $user['name'])[0]) ?></span>
            </button>
            <div id="user-menu-panel" class="invisible absolute right-0 mt-3 w-52 translate-y-2 rounded-xl border border-white/10 bg-coal/95 p-2 opacity-0 shadow-2xl backdrop-blur transition">
              <a class="block rounded-lg px-4 py-2.5 text-sm hover:bg-white/5" href="<?= url('profile.php') ?>">My profile</a>
              <a class="block rounded-lg px-4 py-2.5 text-sm hover:bg-white/5" href="<?= url('profile.php#orders') ?>">My orders</a>
              <a class="block rounded-lg px-4 py-2.5 text-sm hover:bg-white/5" href="<?= url('profile.php#reservations') ?>">Reservations</a>
              <?php if (is_admin()): ?>
                <a class="block rounded-lg px-4 py-2.5 text-sm text-gold hover:bg-white/5" href="<?= url('admin/index.php') ?>">Admin dashboard</a>
              <?php endif; ?>
              <a class="block rounded-lg px-4 py-2.5 text-sm text-rose-300 hover:bg-white/5" href="<?= url('logout.php') ?>">Sign out</a>
            </div>
          </div>
        <?php else: ?>
          <a href="<?= url('login.php') ?>" data-transition
             class="hidden md:inline text-xs uppercase tracking-[.25em] text-ivory/80 hover:text-gold">Sign in</a>
        <?php endif; ?>

        <button id="cart-btn" class="relative grid h-11 w-11 place-items-center rounded-full border border-white/15 hover:border-gold magnetic"
                aria-label="Open cart" aria-controls="mini-cart" aria-expanded="false">
          <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M6 7h12l-1 12H7L6 7Z"/><path d="M9 7a3 3 0 0 1 6 0"/></svg>
          <span id="cart-badge" class="cart-badge" data-count="0">0</span>
        </button>

        <button id="menu-toggle" class="grid h-11 w-11 place-items-center rounded-full border border-white/15 md:hidden"
                aria-label="Open menu" aria-controls="mobile-menu" aria-expanded="false">
          <span class="burger"><span></span><span></span></span>
        </button>
      </div>
    </nav>
  </header>

  <!-- Mobile menu -->
  <div id="mobile-menu" class="mobile-menu" hidden>
    <ul class="flex flex-col gap-6 font-serif text-4xl">
      <?php foreach ($navLinks as $file => $label): ?>
        <li><a href="<?= url($file) ?>" data-transition class="hover:text-gold"><?= e($label) ?></a></li>
      <?php endforeach; ?>
      <?php if ($user): ?>
        <li><a href="<?= url('profile.php') ?>" data-transition class="hover:text-gold">My profile</a></li>
        <?php if (is_admin()): ?><li><a href="<?= url('admin/index.php') ?>" class="text-gold">Admin</a></li><?php endif; ?>
        <li><a href="<?= url('logout.php') ?>" class="text-rose-300">Sign out</a></li>
      <?php else: ?>
        <li><a href="<?= url('login.php') ?>" data-transition class="text-gold">Sign in</a></li>
      <?php endif; ?>
    </ul>
  </div>

  <!-- Mini cart drawer -->
  <div id="cart-overlay" class="drawer-overlay" hidden></div>
  <aside id="mini-cart" class="mini-cart" aria-label="Shopping cart" aria-hidden="true">
    <div class="flex items-center justify-between border-b border-white/10 px-6 py-5">
      <h2 class="font-serif text-3xl">Your order</h2>
      <button id="cart-close" class="grid h-10 w-10 place-items-center rounded-full border border-white/15 hover:border-gold" aria-label="Close cart">✕</button>
    </div>
    <div id="mini-cart-items" class="flex-1 overflow-y-auto px-6 py-4"></div>
    <div class="border-t border-white/10 px-6 py-5">
      <div class="mb-4 flex items-center justify-between text-sm text-ivory/70">
        <span>Subtotal</span><span id="mini-cart-subtotal" class="font-semibold text-ivory">₱0.00</span>
      </div>
      <a href="<?= url('cart.php') ?>" data-transition class="btn-ghost w-full justify-center mb-3">View full cart</a>
      <a href="<?= url('checkout.php') ?>" data-transition class="btn-gold w-full justify-center magnetic">Checkout</a>
    </div>
  </aside>

  <!-- Toasts -->
  <div id="toasts" class="fixed bottom-5 right-5 z-[90] flex flex-col gap-3" role="status" aria-live="polite">
    <?php foreach (flash_pull() as $f): ?>
      <div class="toast toast--<?= e($f['type']) ?>" data-flash><?= e($f['message']) ?></div>
    <?php endforeach; ?>
  </div>

  <main id="main">
