  </main>

  <footer class="relative mt-32 border-t border-white/10 bg-coal">
    <div class="mx-auto grid max-w-7xl gap-12 px-5 py-16 md:grid-cols-4 md:px-8">
      <div class="md:col-span-2">
        <p class="font-serif text-4xl"><span class="text-gold">A</span>urum Kitchen</p>
        <p class="mt-4 max-w-sm text-ivory/60"><?= e(APP_TAGLINE) ?>. Heritage recipes, reimagined with fire, patience and gold-standard ingredients.</p>
        <form class="mt-8 flex max-w-sm gap-2" onsubmit="event.preventDefault(); AK.toast('Thank you — you are on the list.', 'success'); this.reset();">
          <label for="news-email" class="sr-only">Email</label>
          <input id="news-email" type="email" required placeholder="Your email" class="input flex-1">
          <button class="btn-gold">Join</button>
        </form>
      </div>
      <div>
        <h3 class="text-xs uppercase tracking-[.3em] text-gold">Explore</h3>
        <ul class="mt-5 space-y-3 text-ivory/70">
          <li><a class="hover:text-gold" href="<?= url('menu.php') ?>">Menu</a></li>
          <li><a class="hover:text-gold" href="<?= url('reservations.php') ?>">Reservations</a></li>
          <li><a class="hover:text-gold" href="<?= url('track.php') ?>">Track an order</a></li>
          <li><a class="hover:text-gold" href="<?= url('profile.php') ?>">My account</a></li>
        </ul>
      </div>
      <div>
        <h3 class="text-xs uppercase tracking-[.3em] text-gold">Visit</h3>
        <address class="mt-5 space-y-3 not-italic text-ivory/70">
          <p><?= e(APP_ADDRESS) ?></p>
          <p><a class="hover:text-gold" href="tel:<?= e(preg_replace('/\s+/', '', APP_PHONE)) ?>"><?= e(APP_PHONE) ?></a></p>
          <p><a class="hover:text-gold" href="mailto:<?= e(APP_EMAIL) ?>"><?= e(APP_EMAIL) ?></a></p>
          <p class="pt-2 text-sm">Tue–Sun · 11:00 – 22:00<br>Closed Mondays</p>
        </address>
      </div>
    </div>
    <div class="border-t border-white/5 py-6 text-center text-xs tracking-widest text-ivory/40">
      © <?= date('Y') ?> <?= e(APP_NAME) ?>. All rights reserved.
    </div>
  </footer>

  <!-- Animation libraries (optional enhancement: pages degrade gracefully without them) -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js" defer></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js" defer></script>
  <script src="<?= url('assets/js/app.js') ?>" defer></script>
  <?php foreach (($extraScripts ?? []) as $src): ?>
    <script src="<?= e($src) ?>" defer></script>
  <?php endforeach; ?>
</body>
</html>
