<?php
require_once __DIR__ . '/../config/db.php';

/* ---------- Output / escaping ---------- */

/** Escape for HTML output. */
function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Format money with currency symbol. */
function money(float|int|string $amount): string
{
    return CURRENCY . number_format((float) $amount, 2);
}

function url(string $path = ''): string
{
    return BASE_URL . '/' . ltrim($path, '/');
}

function redirect(string $path): never
{
    header('Location: ' . (str_starts_with($path, 'http') ? $path : url($path)));
    exit;
}

/* ---------- CSRF ---------- */

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_verify(?string $token = null): bool
{
    $token ??= $_POST['csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    return is_string($token) && !empty($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $token);
}

/** Abort the request when the CSRF token is invalid. */
function csrf_require(): void
{
    if (!csrf_verify()) {
        http_response_code(419);
        exit('Session expired. Please go back, refresh and try again.');
    }
}

/* ---------- Flash messages ---------- */

function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function flash_pull(): array
{
    $items = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $items;
}

/* ---------- Input helpers ---------- */

function input(string $key, string $default = ''): string
{
    $v = $_POST[$key] ?? $_GET[$key] ?? $default;
    return is_string($v) ? trim($v) : $default;
}

function is_post(): bool
{
    return ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST';
}

function json_response(array $data, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/* ---------- Catalogue helpers ---------- */

function order_statuses(): array
{
    return [
        'placed'     => 'Order placed',
        'confirmed'  => 'Confirmed',
        'preparing'  => 'Preparing',
        'ready'      => 'Out for delivery / Ready',
        'completed'  => 'Completed',
    ];
}

function status_badge_class(string $status): string
{
    return match ($status) {
        'placed'    => 'bg-sky-500/15 text-sky-300 ring-sky-400/30',
        'confirmed' => 'bg-indigo-500/15 text-indigo-300 ring-indigo-400/30',
        'preparing' => 'bg-amber-500/15 text-amber-300 ring-amber-400/30',
        'ready'     => 'bg-emerald-500/15 text-emerald-300 ring-emerald-400/30',
        'completed' => 'bg-gold/15 text-gold ring-gold/30',
        'cancelled' => 'bg-rose-500/15 text-rose-300 ring-rose-400/30',
        default     => 'bg-white/10 text-white/70 ring-white/20',
    };
}

/** Generate a unique, readable order number, e.g. AK-241124-7F3A */
function generate_order_number(): string
{
    return 'AK-' . date('ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 4));
}

/** Compute cart totals from a subtotal and order type. */
function compute_totals(float $subtotal, string $orderType, float $discount = 0.0): array
{
    $discount = min($discount, $subtotal);
    $taxable  = $subtotal - $discount;
    $tax      = round($taxable * TAX_RATE, 2);
    $delivery = 0.0;
    if ($orderType === 'delivery' && $subtotal > 0) {
        $delivery = $subtotal >= FREE_DELIVERY_MIN ? 0.0 : DELIVERY_FEE;
    }
    return [
        'subtotal' => round($subtotal, 2),
        'discount' => round($discount, 2),
        'tax'      => $tax,
        'delivery' => $delivery,
        'total'    => round($taxable + $tax + $delivery, 2),
    ];
}

/* ---------- Upload validation ---------- */

/**
 * Validate and store an uploaded image. Returns the stored filename.
 * @throws RuntimeException on any validation failure.
 */
function save_uploaded_image(array $file): string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Upload failed. Please try again.');
    }
    if ($file['size'] > 3 * 1024 * 1024) {
        throw new RuntimeException('Image must be 3 MB or smaller.');
    }
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!isset($allowed[$mime])) {
        throw new RuntimeException('Only JPG, PNG or WEBP images are allowed.');
    }
    if (!@getimagesize($file['tmp_name'])) {
        throw new RuntimeException('That file is not a valid image.');
    }
    if (!is_dir(UPLOAD_DIR)) {
        mkdir(UPLOAD_DIR, 0755, true);
    }
    $name = bin2hex(random_bytes(12)) . '.' . $allowed[$mime];
    if (!move_uploaded_file($file['tmp_name'], UPLOAD_DIR . $name)) {
        throw new RuntimeException('Could not save the uploaded image.');
    }
    return $name;
}

/** Resolve a product image (remote URL or uploaded file name) to a URL. */
function image_url(?string $image): string
{
    if (!$image) {
        return 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=900&q=70';
    }
    return str_starts_with($image, 'http') ? $image : UPLOAD_URL . $image;
}
