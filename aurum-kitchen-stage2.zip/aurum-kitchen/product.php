<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/components.php';

$id   = (int) ($_GET['id'] ?? 0);
$stmt = db()->prepare(
    'SELECT p.*, c.name AS category_name, c.slug AS category_slug
       FROM products p JOIN categories c ON c.id = p.category_id
      WHERE p.id = ? AND p.is_available = 1'
);
$stmt->execute([$id]);
$product = $stmt->fetch();

if (!$product) {
    http_response_code(404);
    $pageTitle = 'Dish not found';
    require_once __DIR__ . '/includes/header.php';
    echo '<section class="grid min-h-[70vh] place-content-center px-6 pt-32 text-center">
            <p class="eyebrow">404</p><h1 class="mt-4 font-serif text-6xl">We couldn\'t find that dish</h1>
            <a href="' . e(url('menu.php')) . '" class="btn-gold mx-auto mt-10">Back to the menu</a></section>';
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

$user = current_user();

/* ---------- Review submission ---------- */
if (is_post() && input('action') === 'review') {
    csrf_require();
    $user = require_login();
    $rating  = (int) input('rating');
    $comment = mb_substr(input('comment'), 0, 600);

    if ($rating < 1 || $rating > 5) {
        flash('error', 'Please choose a rating from 1 to 5 stars.');
    } else {
        db()->prepare(
            'INSERT INTO reviews (product_id, user_id, rating, comment) VALUES (?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE rating = VALUES(rating), comment = VALUES(comment), created_at = NOW()'
        )->execute([$id, $user['id'], $rating, $comment !== '' ? $comment : null]);
        flash('success', 'Thank you for your review.');
    }
    redirect('product.php?id=' . $id . '#reviews');
}

/* ---------- Data ---------- */
$opts = db()->prepare('SELECT id, type, name, price_delta FROM product_options WHERE product_id = ? ORDER BY type, id');
$opts->execute([$id]);
$sizes  = [];
$addons = [];
foreach ($opts->fetchAll() as $o) {
    if ($o['type'] === 'size') { $sizes[] = $o; } else { $addons[] = $o; }
}

$gallery = array_values(array_filter(array_merge(
    [image_url($product['image'])],
    array_map('trim', explode('|', (string) $product['gallery']))
)));

$rev = db()->prepare(
    'SELECT r.user_id, r.rating, r.comment, r.created_at, u.name
       FROM reviews r JOIN users u ON u.id = r.user_id
      WHERE r.product_id = ? ORDER BY r.created_at DESC LIMIT 20'
);
$rev->execute([$id]);
$reviews = $rev->fetchAll();
$reviewCount = count($reviews);
$reviewAvg   = $reviewCount ? array_sum(array_column($reviews, 'rating')) / $reviewCount : (float) $product['rating'];

$myReview = null;
if ($user) {
    foreach ($reviews as $r) { if ((int) $r['user_id'] === (int) $user['id']) { $myReview = $r; break; } }
}

$relStmt = db()->prepare(
    'SELECT p.*, c.slug AS category_slug FROM products p JOIN categories c ON c.id = p.category_id
      WHERE p.category_id = ? AND p.id <> ? AND p.is_available = 1 ORDER BY p.rating DESC LIMIT 4'
);
$relStmt->execute([$product['category_id'], $id]);
$related = $relStmt->fetchAll();

$favIds = user_favorite_ids($user['id'] ?? null);
$isFav  = in_array($id, $favIds, true);

$pageTitle = $product['name'];
require_once __DIR__ . '/includes/header.php';
?>

<section class="mx-auto max-w-7xl px-5 pb-10 pt-32 md:px-8">
  <nav aria-label="Breadcrumb" class="mb-8 text-xs uppercase tracking-[.2em] text-ivory/50">
    <a href="<?= url('menu.php') ?>" data-transition class="hover:text-gold">Menu</a>
    <span class="mx-2">/</span>
    <a href="<?= url('menu.php?cat=' . urlencode($product['category_slug'])) ?>" data-transition class="hover:text-gold"><?= e($product['category_name']) ?></a>
    <span class="mx-2">/</span><span class="text-ivory"><?= e($product['name']) ?></span>
  </nav>

  <div class="grid gap-12 lg:grid-cols-2">

    <!-- Gallery -->
    <div data-reveal="left">
      <div class="zoom-wrap relative aspect-[4/3] overflow-hidden rounded-[2rem] border border-white/10">
        <img id="main-image" src="<?= e($gallery[0]) ?>" alt="<?= e($product['name']) ?>" class="h-full w-full object-cover">
      </div>
      <?php if (count($gallery) > 1): ?>
        <div class="mt-4 grid grid-cols-4 gap-3" role="list" aria-label="More photos">
          <?php foreach ($gallery as $i => $src): ?>
            <button type="button" role="listitem" data-thumb="<?= e($src) ?>" aria-label="Show photo <?= $i + 1 ?>"
                    class="thumb aspect-square overflow-hidden rounded-xl border <?= $i === 0 ? 'border-gold' : 'border-white/10' ?>">
              <img src="<?= e($src) ?>" alt="" loading="lazy" class="h-full w-full object-cover">
            </button>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

    <!-- Details -->
    <div data-reveal="right">
      <div class="flex items-center gap-3">
        <p class="eyebrow"><?= e($product['category_name']) ?></p>
        <?php if ($product['is_featured']): ?><span class="rounded-full bg-gold px-3 py-1 text-[10px] font-semibold uppercase tracking-widest text-ink">Chef's pick</span><?php endif; ?>
      </div>
      <h1 class="mt-3 font-serif text-5xl leading-tight md:text-6xl"><?= e($product['name']) ?></h1>

      <div class="mt-4 flex items-center gap-3 text-sm">
        <?= stars($reviewAvg) ?>
        <a href="#reviews" class="text-ivory/60 hover:text-gold"><?= number_format($reviewAvg, 1) ?> · <?= $reviewCount ?> review<?= $reviewCount === 1 ? '' : 's' ?></a>
      </div>

      <p class="mt-6 text-lg leading-relaxed text-ivory/75"><?= e($product['description'] ?: $product['short_desc']) ?></p>
      <div class="mt-4 flex flex-wrap gap-1.5"><?= tag_pills($product['dietary_tags']) ?></div>

      <form id="product-form" class="mt-8 space-y-7 border-t border-white/10 pt-8" onsubmit="return false"
            data-id="<?= (int) $product['id'] ?>" data-name="<?= e($product['name']) ?>"
            data-price="<?= e((string) $product['price']) ?>" data-image="<?= e($gallery[0]) ?>">

        <?php if ($sizes): ?>
          <fieldset>
            <legend class="label">Size</legend>
            <div class="flex flex-wrap gap-3">
              <?php foreach ($sizes as $i => $o): ?>
                <label class="opt cursor-pointer">
                  <input type="radio" name="size" class="peer sr-only" value="<?= (int) $o['id'] ?>"
                         data-name="<?= e($o['name']) ?>" data-delta="<?= e((string) $o['price_delta']) ?>" <?= $i === 0 ? 'checked' : '' ?>>
                  <span class="block rounded-xl border border-white/15 px-5 py-3 text-sm transition peer-checked:border-gold peer-checked:bg-gold/10 peer-checked:text-gold peer-focus-visible:ring-2 peer-focus-visible:ring-gold">
                    <?= e($o['name']) ?>
                    <?php if ((float) $o['price_delta'] > 0): ?><span class="ml-1 text-ivory/50">+<?= money($o['price_delta']) ?></span><?php endif; ?>
                  </span>
                </label>
              <?php endforeach; ?>
            </div>
          </fieldset>
        <?php endif; ?>

        <?php if ($addons): ?>
          <fieldset>
            <legend class="label">Add-ons</legend>
            <div class="grid gap-3 sm:grid-cols-2">
              <?php foreach ($addons as $o): ?>
                <label class="cursor-pointer">
                  <input type="checkbox" name="addon" class="peer sr-only" value="<?= (int) $o['id'] ?>"
                         data-name="<?= e($o['name']) ?>" data-delta="<?= e((string) $o['price_delta']) ?>">
                  <span class="flex items-center justify-between rounded-xl border border-white/15 px-4 py-3 text-sm transition peer-checked:border-gold peer-checked:bg-gold/10 peer-focus-visible:ring-2 peer-focus-visible:ring-gold">
                    <?= e($o['name']) ?><span class="text-gold">+<?= money($o['price_delta']) ?></span>
                  </span>
                </label>
              <?php endforeach; ?>
            </div>
          </fieldset>
        <?php endif; ?>

        <div>
          <label for="notes" class="label">Special notes <span class="normal-case tracking-normal text-ivory/40">(optional)</span></label>
          <textarea id="notes" rows="2" maxlength="200" class="input" placeholder="Allergies, spice level, no onions…"></textarea>
        </div>

        <div class="flex flex-wrap items-center gap-5">
          <div class="flex items-center rounded-full border border-white/20" role="group" aria-label="Quantity">
            <button type="button" id="qty-dec" class="grid h-12 w-12 place-items-center text-xl hover:text-gold" aria-label="Decrease quantity">−</button>
            <output id="qty" class="w-8 text-center font-semibold" aria-live="polite">1</output>
            <button type="button" id="qty-inc" class="grid h-12 w-12 place-items-center text-xl hover:text-gold" aria-label="Increase quantity">+</button>
          </div>
          <button type="button" id="add-btn" class="btn-gold magnetic flex-1 justify-center sm:flex-none">
            Add to cart · <span id="total"><?= money($product['price']) ?></span>
          </button>
          <button type="button" data-fav="<?= (int) $product['id'] ?>" aria-pressed="<?= $isFav ? 'true' : 'false' ?>"
                  class="grid h-12 w-12 place-items-center rounded-full border border-white/20 hover:border-gold" aria-label="Save to favorites">
            <svg class="h-5 w-5 <?= $isFav ? 'fill-gold text-gold' : 'fill-transparent text-ivory' ?>" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.6"><path d="M12 21s-7-4.6-9.3-9A5.3 5.3 0 0 1 12 6.5 5.3 5.3 0 0 1 21.3 12C19 16.4 12 21 12 21Z"/></svg>
          </button>
        </div>
      </form>

      <!-- Ingredients / allergens -->
      <div class="mt-10 grid gap-4 sm:grid-cols-2">
        <?php if ($product['ingredients']): ?>
          <div class="card p-5"><p class="label">Ingredients</p><p class="text-sm text-ivory/75"><?= e($product['ingredients']) ?></p></div>
        <?php endif; ?>
        <div class="card p-5">
          <p class="label">Allergens</p>
          <p class="text-sm <?= $product['allergens'] ? 'text-amber-300' : 'text-ivory/60' ?>"><?= e($product['allergens'] ?: 'None declared') ?></p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Reviews -->
<section id="reviews" class="mx-auto mt-20 max-w-7xl px-5 md:px-8">
  <div class="grid gap-12 lg:grid-cols-3">
    <div data-reveal>
      <p class="eyebrow">Reviews</p>
      <h2 class="mt-3 font-serif text-5xl">What guests <span class="italic text-gold">say</span></h2>
      <p class="mt-6 font-serif text-7xl text-gold"><?= number_format($reviewAvg, 1) ?></p>
      <p class="mt-1"><?= stars($reviewAvg) ?></p>
      <p class="mt-1 text-sm text-ivory/50"><?= $reviewCount ?> review<?= $reviewCount === 1 ? '' : 's' ?></p>

      <?php if ($user): ?>
        <form method="post" class="mt-10 space-y-4">
          <?= csrf_field() ?><input type="hidden" name="action" value="review">
          <fieldset>
            <legend class="label"><?= $myReview ? 'Update your review' : 'Write a review' ?></legend>
            <div class="flex flex-row-reverse justify-end gap-1 text-3xl" id="star-input">
              <?php for ($s = 5; $s >= 1; $s--): ?>
                <input type="radio" name="rating" id="star<?= $s ?>" value="<?= $s ?>" class="peer sr-only" <?= ($myReview['rating'] ?? 0) == $s ? 'checked' : '' ?> required>
                <label for="star<?= $s ?>" class="cursor-pointer text-white/20 transition peer-checked:text-gold" title="<?= $s ?> star<?= $s > 1 ? 's' : '' ?>">★</label>
              <?php endfor; ?>
            </div>
          </fieldset>
          <textarea name="comment" rows="3" maxlength="600" class="input" placeholder="Tell others what you thought…"><?= e($myReview['comment'] ?? '') ?></textarea>
          <button class="btn-gold">Submit review</button>
        </form>
      <?php else: ?>
        <a href="<?= url('login.php') ?>" data-transition class="btn-ghost mt-10">Sign in to review</a>
      <?php endif; ?>
    </div>

    <div class="space-y-5 lg:col-span-2">
      <?php if (!$reviews): ?>
        <div class="card p-8 text-ivory/60">No reviews yet — be the first to share your thoughts.</div>
      <?php endif; ?>
      <?php foreach ($reviews as $r): ?>
        <article class="card p-6" data-reveal>
          <div class="flex items-center justify-between">
            <p class="font-semibold"><?= e($r['name']) ?></p>
            <time class="text-xs text-ivory/40" datetime="<?= e($r['created_at']) ?>"><?= e(date('M j, Y', strtotime($r['created_at']))) ?></time>
          </div>
          <p class="mt-1"><?= stars((float) $r['rating']) ?></p>
          <?php if ($r['comment']): ?><p class="mt-3 text-ivory/75"><?= e($r['comment']) ?></p><?php endif; ?>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Related -->
<?php if ($related): ?>
<section class="mx-auto mt-24 max-w-7xl px-5 md:px-8">
  <div data-reveal>
    <p class="eyebrow">You may also like</p>
    <h2 class="mt-3 font-serif text-5xl">More from <span class="italic text-gold"><?= e($product['category_name']) ?></span></h2>
  </div>
  <div class="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
    <?php foreach ($related as $i => $p) { echo product_card($p, $favIds, $i); } ?>
  </div>
</section>
<?php endif; ?>

<?php
$extraScripts = [url('assets/js/product.js')];
require_once __DIR__ . '/includes/footer.php';
