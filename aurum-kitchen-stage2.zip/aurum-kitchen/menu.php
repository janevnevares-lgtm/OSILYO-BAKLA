<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/components.php';

$user   = current_user();
$favIds = user_favorite_ids($user['id'] ?? null);

$categories = db()->query('SELECT id, name, slug FROM categories ORDER BY sort_order')->fetchAll();
$products   = db()->query(
    'SELECT p.*, c.slug AS category_slug, c.name AS category_name
       FROM products p JOIN categories c ON c.id = p.category_id
      WHERE p.is_available = 1
      ORDER BY c.sort_order, p.is_featured DESC, p.name'
)->fetchAll();

$maxPrice = $products ? (int) ceil(max(array_column($products, 'price')) / 100) * 100 : 2000;

// Collect the dietary tags that actually exist, for the filter chips
$allTags = [];
foreach ($products as $p) {
    foreach (array_filter(array_map('trim', explode(',', (string) $p['dietary_tags']))) as $t) {
        $allTags[$t] = true;
    }
}
ksort($allTags);

$initialCat = preg_replace('/[^a-z0-9\-]/', '', input('cat', 'all'));

$pageTitle = 'Menu';
require_once __DIR__ . '/includes/header.php';
?>

<!-- Page header -->
<section class="relative isolate overflow-hidden pb-14 pt-40 text-center">
  <img src="https://images.unsplash.com/photo-1424847651672-bf20a4b0982b?auto=format&fit=crop&w=1800&q=60" alt=""
       class="ken-burns absolute inset-0 -z-20 h-full w-full object-cover opacity-50">
  <div class="absolute inset-0 -z-10 bg-gradient-to-b from-ink/60 via-ink/70 to-ink"></div>
  <p class="eyebrow" data-reveal>The menu</p>
  <h1 class="mt-4 font-serif text-6xl md:text-8xl" data-reveal style="--d:.15s">Crafted <span class="italic text-gold-gradient">with fire</span></h1>
  <p class="mx-auto mt-6 max-w-xl px-6 text-ivory/70" data-reveal style="--d:.3s">Every dish is cooked to order. Add to your cart and we'll have it at your door, ready for pickup, or waiting at your table.</p>
</section>

<section class="mx-auto max-w-7xl px-5 md:px-8" id="menu-app" data-initial-cat="<?= e($initialCat ?: 'all') ?>" data-max-price="<?= $maxPrice ?>">

  <!-- Category tabs -->
  <div class="sticky top-[72px] z-30 -mx-5 border-y border-white/10 bg-ink/80 px-5 backdrop-blur-xl md:-mx-8 md:px-8">
    <div class="no-scrollbar flex gap-2 overflow-x-auto py-3" role="tablist" aria-label="Menu categories">
      <button role="tab" data-cat="all" aria-selected="true" class="cat-tab">All</button>
      <?php foreach ($categories as $c): ?>
        <button role="tab" data-cat="<?= e($c['slug']) ?>" aria-selected="false" class="cat-tab"><?= e($c['name']) ?></button>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Controls -->
  <div class="mt-8 grid gap-4 md:grid-cols-12">
    <div class="relative md:col-span-5">
      <label for="menu-search" class="sr-only">Search dishes</label>
      <svg class="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-ivory/40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
      <input id="menu-search" type="search" class="input !pl-12" placeholder="Search dishes, ingredients…" autocomplete="off">
    </div>
    <div class="md:col-span-4">
      <label for="menu-price" class="label !mb-1 flex justify-between">Max price <span id="menu-price-out" class="text-gold"><?= money($maxPrice) ?></span></label>
      <input id="menu-price" type="range" min="100" max="<?= $maxPrice ?>" step="50" value="<?= $maxPrice ?>" class="w-full accent-[#C9A24B]">
    </div>
    <div class="md:col-span-3">
      <label for="menu-sort" class="sr-only">Sort by</label>
      <select id="menu-sort" class="input">
        <option value="featured">Sort: Recommended</option>
        <option value="price-asc">Price: low to high</option>
        <option value="price-desc">Price: high to low</option>
        <option value="rating">Top rated</option>
        <option value="name">Name A–Z</option>
      </select>
    </div>
  </div>

  <!-- Dietary chips -->
  <div class="mt-5 flex flex-wrap items-center gap-2" role="group" aria-label="Dietary filters">
    <span class="mr-2 text-xs uppercase tracking-[.25em] text-ivory/50">Dietary</span>
    <?php foreach (array_keys($allTags) as $tag): ?>
      <button type="button" class="chip" data-tag="<?= e(mb_strtolower($tag)) ?>" aria-pressed="false"><?= e(ucfirst($tag)) ?></button>
    <?php endforeach; ?>
    <button type="button" id="menu-reset" class="ml-auto hidden text-xs uppercase tracking-widest text-gold hover:underline">Clear filters</button>
  </div>

  <p class="mt-8 text-sm text-ivory/50" id="menu-count" aria-live="polite"></p>

  <!-- Skeletons (shown briefly while the grid initialises) -->
  <div id="menu-skeleton" class="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3" aria-hidden="true">
    <?php for ($i = 0; $i < 6; $i++): ?>
      <div class="card overflow-hidden"><div class="skeleton aspect-[4/3] !rounded-none"></div><div class="space-y-3 p-5"><div class="skeleton h-6 w-2/3"></div><div class="skeleton h-4 w-full"></div><div class="skeleton h-10 w-1/3"></div></div></div>
    <?php endfor; ?>
  </div>

  <!-- Product grid -->
  <div id="menu-grid" class="mt-6 hidden grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
    <?php foreach ($products as $i => $p): echo product_card($p, $favIds, $i); endforeach; ?>
  </div>

  <div id="menu-empty" class="hidden py-24 text-center">
    <p class="font-serif text-4xl">Nothing matches that…</p>
    <p class="mt-3 text-ivory/60">Try removing a filter or searching for something else.</p>
  </div>
</section>

<style>
  .no-scrollbar { scrollbar-width: none; } .no-scrollbar::-webkit-scrollbar { display: none; }
  .cat-tab { flex: none; padding: .6rem 1.4rem; border-radius: 999px; font-size: .72rem; letter-spacing: .22em; text-transform: uppercase;
             border: 1px solid transparent; color: rgba(245,239,230,.7); transition: all .3s; }
  .cat-tab:hover { color: var(--gold); }
  .cat-tab[aria-selected="true"] { background: var(--gold); color: var(--ink); font-weight: 600; }
  .chip { padding: .4rem 1rem; border-radius: 999px; border: 1px solid rgba(255,255,255,.15); font-size: .78rem; transition: all .3s; }
  .chip:hover { border-color: var(--gold); }
  .chip[aria-pressed="true"] { background: rgba(201,162,75,.18); border-color: var(--gold); color: var(--gold); }
  [data-product-card].is-hidden { display: none; }
</style>

<?php
$extraScripts = [url('assets/js/menu.js')];
require_once __DIR__ . '/includes/footer.php';
