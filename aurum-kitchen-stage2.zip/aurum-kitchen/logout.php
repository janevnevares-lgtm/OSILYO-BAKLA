<?php
require_once __DIR__ . '/includes/auth.php';

// Sign out, then start a fresh session so we can show a confirmation message.
logout_user();
session_start();
session_regenerate_id(true);
flash('info', 'You have been signed out.');
redirect('index.php');
