<?php
require_once __DIR__ . '/includes/auth.php';

if (is_logged_in()) {
    redirect('index.php');
}

$errors = [];
$old    = ['name' => '', 'email' => '', 'phone' => ''];

if (is_post()) {
    csrf_require();
    $old = [
        'name'  => input('name'),
        'email' => mb_strtolower(input('email')),
        'phone' => input('phone'),
    ];
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['password_confirm'] ?? '';

    if (mb_strlen($old['name']) < 2 || mb_strlen($old['name']) > 120) {
        $errors['name'] = 'Please enter your full name.';
    }
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL) || mb_strlen($old['email']) > 190) {
        $errors['email'] = 'Enter a valid email address.';
    }
    if ($old['phone'] !== '' && !preg_match('/^[0-9+()\-\s]{7,20}$/', $old['phone'])) {
        $errors['phone'] = 'Enter a valid phone number.';
    }
    if (strlen($password) < 8 || !preg_match('/[A-Za-z]/', $password) || !preg_match('/\d/', $password)) {
        $errors['password'] = 'Use at least 8 characters, including a letter and a number.';
    }
    if ($password !== $confirm) {
        $errors['password_confirm'] = 'Passwords do not match.';
    }

    if (!$errors) {
        $exists = db()->prepare('SELECT 1 FROM users WHERE email = ?');
        $exists->execute([$old['email']]);
        if ($exists->fetchColumn()) {
            $errors['email'] = 'An account with that email already exists.';
        }
    }

    if (!$errors) {
        // Public sign-up always creates a "customer"; admins are created manually.
        db()->prepare('INSERT INTO users (name, email, phone, password_hash, role) VALUES (?, ?, ?, ?, "customer")')
            ->execute([$old['name'], $old['email'], $old['phone'] ?: null, password_hash($password, PASSWORD_DEFAULT)]);
        login_user((int) db()->lastInsertId());
        flash('success', 'Welcome to ' . APP_NAME . '!');
        redirect('index.php');
    }
}

$pageTitle = 'Create account';
require_once __DIR__ . '/includes/header.php';

/** Small helper to print a field error. */
$err = fn(string $k) => !empty($errors[$k]) ? '<p class="field-error">' . e($errors[$k]) . '</p>' : '';
?>
<section class="grid min-h-screen lg:grid-cols-2">
  <div class="relative hidden overflow-hidden lg:block">
    <img src="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=1400&q=70" alt=""
         class="ken-burns absolute inset-0 h-full w-full object-cover">
    <div class="absolute inset-0 bg-gradient-to-t from-ink via-ink/40 to-ink/10"></div>
    <div class="absolute inset-x-0 bottom-0 p-14">
      <p class="eyebrow">Join Aurum</p>
      <p class="mt-4 max-w-md font-serif text-5xl leading-tight">Every great meal begins with a <span class="text-gold-gradient italic">reservation.</span></p>
    </div>
  </div>

  <div class="flex items-center justify-center px-6 pb-16 pt-32 lg:pt-24">
    <div class="w-full max-w-md" data-reveal>
      <p class="eyebrow">Create account</p>
      <h1 class="mt-3 font-serif text-5xl">Join the table</h1>
      <p class="mt-3 text-ivory/60">Save your favorites, track orders and book faster.</p>

      <form method="post" class="mt-8 space-y-5" novalidate data-validate>
        <?= csrf_field() ?>
        <div>
          <label class="label" for="name">Full name</label>
          <input class="input" id="name" name="name" value="<?= e($old['name']) ?>" autocomplete="name" required>
          <?= $err('name') ?>
        </div>
        <div>
          <label class="label" for="email">Email</label>
          <input class="input" type="email" id="email" name="email" value="<?= e($old['email']) ?>" autocomplete="email" required>
          <?= $err('email') ?>
        </div>
        <div>
          <label class="label" for="phone">Phone <span class="normal-case tracking-normal text-ivory/40">(optional)</span></label>
          <input class="input" type="tel" id="phone" name="phone" value="<?= e($old['phone']) ?>" autocomplete="tel">
          <?= $err('phone') ?>
        </div>
        <div>
          <label class="label" for="password">Password</label>
          <div class="relative">
            <input class="input pr-14" type="password" id="password" name="password" autocomplete="new-password" minlength="8" required>
            <button type="button" data-toggle-password="password" class="absolute right-3 top-1/2 -translate-y-1/2 text-xs uppercase tracking-widest text-ivory/60 hover:text-gold" aria-label="Show password">Show</button>
          </div>
          <div class="mt-2 h-1 overflow-hidden rounded bg-white/10"><div id="pw-meter" class="h-full w-0 bg-rose-400 transition-all"></div></div>
          <?= $err('password') ?>
        </div>
        <div>
          <label class="label" for="password_confirm">Confirm password</label>
          <input class="input" type="password" id="password_confirm" name="password_confirm" autocomplete="new-password" required>
          <?= $err('password_confirm') ?>
        </div>
        <button class="btn-gold w-full justify-center magnetic" type="submit">Create account</button>
      </form>

      <p class="mt-8 text-center text-sm text-ivory/60">
        Already a member? <a href="<?= url('login.php') ?>" data-transition class="text-gold hover:underline">Sign in</a>
      </p>
    </div>
  </div>
</section>
<?php
$extraScripts = [url('assets/js/auth.js')];
require_once __DIR__ . '/includes/footer.php';
